import { db, auditLogsTable } from "@workspace/db";

export interface LogActionOptions {
  action: "create" | "update" | "delete";
  entity: string;
  entityId?: number | null;
  entityLabel?: string | null;
  details?: Record<string, unknown>;
}

export function logAction(opts: LogActionOptions): void {
  db.insert(auditLogsTable)
    .values({
      action: opts.action,
      entity: opts.entity,
      entityId: opts.entityId ?? null,
      entityLabel: opts.entityLabel ?? null,
      details: opts.details ?? null,
    })
    .catch(() => {});
}
