import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, aircraftTable, flightRecordsTable, maintenanceTable, lifeComponentsTable, alertsTable } from "@workspace/db";
import { serializeDates } from "../utils/serialize";
import { logAction } from "../utils/audit";
import {
  ListAircraftResponse,
  CreateAircraftBody,
  GetAircraftParams,
  GetAircraftResponse,
  UpdateAircraftParams,
  UpdateAircraftBody,
  UpdateAircraftResponse,
  GetAircraftSummaryParams,
  GetAircraftSummaryResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/aircraft", async (req, res): Promise<void> => {
  const aircraft = await db.select().from(aircraftTable).orderBy(desc(aircraftTable.createdAt));
  res.json(ListAircraftResponse.parse(serializeDates(aircraft)));
});

router.post("/aircraft", async (req, res): Promise<void> => {
  const parsed = CreateAircraftBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [a] = await db.insert(aircraftTable).values(parsed.data).returning();
  logAction({ action: "create", entity: "aircraft", entityId: a.id, entityLabel: a.registrationNo });
  res.status(201).json(GetAircraftResponse.parse(serializeDates(a)));
});

router.get("/aircraft/:id", async (req, res): Promise<void> => {
  const params = GetAircraftParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [a] = await db.select().from(aircraftTable).where(eq(aircraftTable.id, params.data.id));
  if (!a) {
    res.status(404).json({ error: "Aircraft not found" });
    return;
  }
  res.json(GetAircraftResponse.parse(serializeDates(a)));
});

router.patch("/aircraft/:id", async (req, res): Promise<void> => {
  const params = UpdateAircraftParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateAircraftBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [a] = await db.update(aircraftTable).set(parsed.data).where(eq(aircraftTable.id, params.data.id)).returning();
  if (!a) {
    res.status(404).json({ error: "Aircraft not found" });
    return;
  }
  logAction({ action: "update", entity: "aircraft", entityId: a.id, entityLabel: a.registrationNo });
  res.json(UpdateAircraftResponse.parse(serializeDates(a)));
});

router.get("/aircraft/:id/summary", async (req, res): Promise<void> => {
  const params = GetAircraftSummaryParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [aircraft] = await db.select().from(aircraftTable).where(eq(aircraftTable.id, params.data.id));
  if (!aircraft) {
    res.status(404).json({ error: "Aircraft not found" });
    return;
  }

  const [recentFlightRecords, pendingMaintenance, lifeComponents, activeAlerts] = await Promise.all([
    db.select().from(flightRecordsTable).where(eq(flightRecordsTable.aircraftId, params.data.id)).orderBy(desc(flightRecordsTable.flightDate)).limit(5),
    db.select().from(maintenanceTable).where(eq(maintenanceTable.aircraftId, params.data.id)).orderBy(maintenanceTable.scheduledDate).limit(5),
    db.select().from(lifeComponentsTable).where(eq(lifeComponentsTable.aircraftId, params.data.id)),
    db.select().from(alertsTable).where(eq(alertsTable.aircraftId, params.data.id)).orderBy(desc(alertsTable.createdAt)).limit(5),
  ]);

  const enrichedFlights = recentFlightRecords.map(f => ({ ...f, aircraftRegistration: aircraft.registrationNo }));
  const enrichedMaintenance = pendingMaintenance.map(m => ({ ...m, aircraftRegistration: aircraft.registrationNo }));
  const enrichedComponents = lifeComponents.map(c => ({
    ...c,
    aircraftRegistration: aircraft.registrationNo,
    remainingLife: c.tbo - c.tsn,
  }));
  const enrichedAlerts = activeAlerts.map(a => ({ ...a, aircraftRegistration: aircraft.registrationNo }));

  res.json(GetAircraftSummaryResponse.parse(serializeDates({
    aircraft,
    recentFlightRecords: enrichedFlights,
    pendingMaintenance: enrichedMaintenance,
    criticalLifeComponents: enrichedComponents,
    activeAlerts: enrichedAlerts,
  })));
});

router.delete("/aircraft/:id", async (req, res): Promise<void> => {
  const params = GetAircraftParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const [a] = await db.delete(aircraftTable).where(eq(aircraftTable.id, params.data.id)).returning();
  if (!a) { res.status(404).json({ error: "Aircraft not found" }); return; }
  logAction({ action: "delete", entity: "aircraft", entityId: a.id, entityLabel: a.registrationNo });
  res.status(204).end();
});

export default router;
