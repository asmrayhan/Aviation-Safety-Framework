import { Router, type IRouter } from "express";
import { eq, desc, gte } from "drizzle-orm";
import { db, maintenanceTable, aircraftTable } from "@workspace/db";
import { serializeDates } from "../utils/serialize";
import { logAction } from "../utils/audit";
import {
  ListMaintenanceQueryParams,
  ListMaintenanceResponse,
  CreateMaintenanceBody,
  GetMaintenanceParams,
  GetMaintenanceResponse,
  UpdateMaintenanceParams,
  UpdateMaintenanceBody,
  UpdateMaintenanceResponse,
  GetUpcomingMaintenanceResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/maintenance/upcoming", async (_req, res): Promise<void> => {
  const today = new Date().toISOString().split("T")[0];
  const records = await db
    .select({
      id: maintenanceTable.id,
      aircraftId: maintenanceTable.aircraftId,
      engineerName: maintenanceTable.engineerName,
      maintenanceType: maintenanceTable.maintenanceType,
      description: maintenanceTable.description,
      status: maintenanceTable.status,
      scheduledDate: maintenanceTable.scheduledDate,
      completedDate: maintenanceTable.completedDate,
      nextDueDate: maintenanceTable.nextDueDate,
      findings: maintenanceTable.findings,
      createdAt: maintenanceTable.createdAt,
      aircraftRegistration: aircraftTable.registrationNo,
    })
    .from(maintenanceTable)
    .leftJoin(aircraftTable, eq(maintenanceTable.aircraftId, aircraftTable.id))
    .where(gte(maintenanceTable.scheduledDate, today))
    .orderBy(maintenanceTable.scheduledDate)
    .limit(20);
  res.json(GetUpcomingMaintenanceResponse.parse(serializeDates(records)));
});

router.get("/maintenance", async (req, res): Promise<void> => {
  const query = ListMaintenanceQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const allRecords = await db
    .select({
      id: maintenanceTable.id,
      aircraftId: maintenanceTable.aircraftId,
      engineerName: maintenanceTable.engineerName,
      maintenanceType: maintenanceTable.maintenanceType,
      description: maintenanceTable.description,
      status: maintenanceTable.status,
      scheduledDate: maintenanceTable.scheduledDate,
      completedDate: maintenanceTable.completedDate,
      nextDueDate: maintenanceTable.nextDueDate,
      findings: maintenanceTable.findings,
      createdAt: maintenanceTable.createdAt,
      aircraftRegistration: aircraftTable.registrationNo,
    })
    .from(maintenanceTable)
    .leftJoin(aircraftTable, eq(maintenanceTable.aircraftId, aircraftTable.id))
    .orderBy(desc(maintenanceTable.scheduledDate));

  let filtered = allRecords;
  if (query.data.aircraftId) {
    filtered = filtered.filter(r => r.aircraftId === query.data.aircraftId);
  }
  if (query.data.status) {
    filtered = filtered.filter(r => r.status === query.data.status);
  }

  res.json(ListMaintenanceResponse.parse(serializeDates(filtered)));
});

router.post("/maintenance", async (req, res): Promise<void> => {
  const parsed = CreateMaintenanceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [record] = await db.insert(maintenanceTable).values(parsed.data).returning();
  const [aircraft] = await db.select().from(aircraftTable).where(eq(aircraftTable.id, record.aircraftId));
  logAction({ action: "create", entity: "maintenance", entityId: record.id, entityLabel: `${aircraft?.registrationNo ?? record.aircraftId} · ${record.maintenanceType}` });
  const result = { ...record, aircraftRegistration: aircraft?.registrationNo ?? null };
  res.status(201).json(GetMaintenanceResponse.parse(serializeDates(result)));
});

router.get("/maintenance/:id", async (req, res): Promise<void> => {
  const params = GetMaintenanceParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [record] = await db
    .select({
      id: maintenanceTable.id,
      aircraftId: maintenanceTable.aircraftId,
      engineerName: maintenanceTable.engineerName,
      maintenanceType: maintenanceTable.maintenanceType,
      description: maintenanceTable.description,
      status: maintenanceTable.status,
      scheduledDate: maintenanceTable.scheduledDate,
      completedDate: maintenanceTable.completedDate,
      nextDueDate: maintenanceTable.nextDueDate,
      findings: maintenanceTable.findings,
      createdAt: maintenanceTable.createdAt,
      aircraftRegistration: aircraftTable.registrationNo,
    })
    .from(maintenanceTable)
    .leftJoin(aircraftTable, eq(maintenanceTable.aircraftId, aircraftTable.id))
    .where(eq(maintenanceTable.id, params.data.id));
  if (!record) {
    res.status(404).json({ error: "Maintenance record not found" });
    return;
  }
  res.json(GetMaintenanceResponse.parse(serializeDates(record)));
});

router.patch("/maintenance/:id", async (req, res): Promise<void> => {
  const params = UpdateMaintenanceParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateMaintenanceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [record] = await db.update(maintenanceTable).set(parsed.data).where(eq(maintenanceTable.id, params.data.id)).returning();
  if (!record) {
    res.status(404).json({ error: "Maintenance record not found" });
    return;
  }
  logAction({ action: "update", entity: "maintenance", entityId: record.id, entityLabel: record.maintenanceType });
  res.json(UpdateMaintenanceResponse.parse(serializeDates(record)));
});

router.delete("/maintenance/:id", async (req, res): Promise<void> => {
  const params = GetMaintenanceParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const [record] = await db.delete(maintenanceTable).where(eq(maintenanceTable.id, params.data.id)).returning();
  if (!record) { res.status(404).json({ error: "Maintenance record not found" }); return; }
  logAction({ action: "delete", entity: "maintenance", entityId: record.id, entityLabel: record.maintenanceType });
  res.status(204).end();
});

export default router;
