import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, investigationsTable, aircraftTable } from "@workspace/db";
import { serializeDates } from "../utils/serialize";
import { logAction } from "../utils/audit";
import {
  ListInvestigationsResponse,
  CreateInvestigationBody,
  GetInvestigationParams,
  GetInvestigationResponse,
  UpdateInvestigationParams,
  UpdateInvestigationBody,
  UpdateInvestigationResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/investigations", async (_req, res): Promise<void> => {
  const records = await db
    .select({
      id: investigationsTable.id,
      safetyReportId: investigationsTable.safetyReportId,
      aircraftId: investigationsTable.aircraftId,
      investigatorName: investigationsTable.investigatorName,
      title: investigationsTable.title,
      investigationType: investigationsTable.investigationType,
      status: investigationsTable.status,
      incidentDate: investigationsTable.incidentDate,
      rootCause: investigationsTable.rootCause,
      contributingFactors: investigationsTable.contributingFactors,
      recommendations: investigationsTable.recommendations,
      createdAt: investigationsTable.createdAt,
      aircraftRegistration: aircraftTable.registrationNo,
    })
    .from(investigationsTable)
    .leftJoin(aircraftTable, eq(investigationsTable.aircraftId, aircraftTable.id))
    .orderBy(desc(investigationsTable.createdAt));
  res.json(ListInvestigationsResponse.parse(serializeDates(records)));
});

router.post("/investigations", async (req, res): Promise<void> => {
  const parsed = CreateInvestigationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [record] = await db.insert(investigationsTable).values(parsed.data).returning();
  let aircraftRegistration = null;
  if (record.aircraftId) {
    const [aircraft] = await db.select().from(aircraftTable).where(eq(aircraftTable.id, record.aircraftId));
    aircraftRegistration = aircraft?.registrationNo ?? null;
  }
  logAction({ action: "create", entity: "investigations", entityId: record.id, entityLabel: record.title });
  res.status(201).json(GetInvestigationResponse.parse(serializeDates({ ...record, aircraftRegistration })));
});

router.get("/investigations/:id", async (req, res): Promise<void> => {
  const params = GetInvestigationParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [record] = await db
    .select({
      id: investigationsTable.id,
      safetyReportId: investigationsTable.safetyReportId,
      aircraftId: investigationsTable.aircraftId,
      investigatorName: investigationsTable.investigatorName,
      title: investigationsTable.title,
      investigationType: investigationsTable.investigationType,
      status: investigationsTable.status,
      incidentDate: investigationsTable.incidentDate,
      rootCause: investigationsTable.rootCause,
      contributingFactors: investigationsTable.contributingFactors,
      recommendations: investigationsTable.recommendations,
      createdAt: investigationsTable.createdAt,
      aircraftRegistration: aircraftTable.registrationNo,
    })
    .from(investigationsTable)
    .leftJoin(aircraftTable, eq(investigationsTable.aircraftId, aircraftTable.id))
    .where(eq(investigationsTable.id, params.data.id));
  if (!record) {
    res.status(404).json({ error: "Investigation not found" });
    return;
  }
  res.json(GetInvestigationResponse.parse(serializeDates(record)));
});

router.patch("/investigations/:id", async (req, res): Promise<void> => {
  const params = UpdateInvestigationParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateInvestigationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [record] = await db.update(investigationsTable).set(parsed.data).where(eq(investigationsTable.id, params.data.id)).returning();
  if (!record) {
    res.status(404).json({ error: "Investigation not found" });
    return;
  }
  logAction({ action: "update", entity: "investigations", entityId: record.id, entityLabel: record.title });
  res.json(UpdateInvestigationResponse.parse(serializeDates(record)));
});

router.delete("/investigations/:id", async (req, res): Promise<void> => {
  const params = GetInvestigationParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const [record] = await db.delete(investigationsTable).where(eq(investigationsTable.id, params.data.id)).returning();
  if (!record) { res.status(404).json({ error: "Investigation not found" }); return; }
  logAction({ action: "delete", entity: "investigations", entityId: record.id, entityLabel: record.title });
  res.status(204).end();
});

export default router;
