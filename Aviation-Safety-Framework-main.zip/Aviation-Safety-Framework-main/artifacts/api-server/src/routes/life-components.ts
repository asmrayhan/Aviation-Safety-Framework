import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, lifeComponentsTable, aircraftTable } from "@workspace/db";
import { serializeDates } from "../utils/serialize";
import { logAction } from "../utils/audit";
import {
  ListLifeComponentsQueryParams,
  ListLifeComponentsResponse,
  CreateLifeComponentBody,
  GetLifeComponentParams,
  GetLifeComponentResponse,
  UpdateLifeComponentParams,
  UpdateLifeComponentBody,
  UpdateLifeComponentResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/life-components", async (req, res): Promise<void> => {
  const query = ListLifeComponentsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const allRecords = await db
    .select({
      id: lifeComponentsTable.id,
      aircraftId: lifeComponentsTable.aircraftId,
      componentName: lifeComponentsTable.componentName,
      partNumber: lifeComponentsTable.partNumber,
      tbo: lifeComponentsTable.tbo,
      tsn: lifeComponentsTable.tsn,
      installDate: lifeComponentsTable.installDate,
      notes: lifeComponentsTable.notes,
      createdAt: lifeComponentsTable.createdAt,
      aircraftRegistration: aircraftTable.registrationNo,
    })
    .from(lifeComponentsTable)
    .leftJoin(aircraftTable, eq(lifeComponentsTable.aircraftId, aircraftTable.id));

  const filtered = query.data.aircraftId
    ? allRecords.filter(r => r.aircraftId === query.data.aircraftId)
    : allRecords;

  const withRemaining = filtered.map(r => ({ ...r, remainingLife: r.tbo - r.tsn }));
  res.json(ListLifeComponentsResponse.parse(serializeDates(withRemaining)));
});

router.post("/life-components", async (req, res): Promise<void> => {
  const parsed = CreateLifeComponentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [record] = await db.insert(lifeComponentsTable).values(parsed.data).returning();
  const [aircraft] = await db.select().from(aircraftTable).where(eq(aircraftTable.id, record.aircraftId));
  logAction({ action: "create", entity: "life-components", entityId: record.id, entityLabel: `${aircraft?.registrationNo ?? record.aircraftId} · ${record.componentName}` });
  const result = { ...record, aircraftRegistration: aircraft?.registrationNo ?? null, remainingLife: record.tbo - record.tsn };
  res.status(201).json(GetLifeComponentResponse.parse(serializeDates(result)));
});

router.get("/life-components/:id", async (req, res): Promise<void> => {
  const params = GetLifeComponentParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [record] = await db
    .select({
      id: lifeComponentsTable.id,
      aircraftId: lifeComponentsTable.aircraftId,
      componentName: lifeComponentsTable.componentName,
      partNumber: lifeComponentsTable.partNumber,
      tbo: lifeComponentsTable.tbo,
      tsn: lifeComponentsTable.tsn,
      installDate: lifeComponentsTable.installDate,
      notes: lifeComponentsTable.notes,
      createdAt: lifeComponentsTable.createdAt,
      aircraftRegistration: aircraftTable.registrationNo,
    })
    .from(lifeComponentsTable)
    .leftJoin(aircraftTable, eq(lifeComponentsTable.aircraftId, aircraftTable.id))
    .where(eq(lifeComponentsTable.id, params.data.id));
  if (!record) {
    res.status(404).json({ error: "Life component not found" });
    return;
  }
  res.json(GetLifeComponentResponse.parse(serializeDates({ ...record, remainingLife: record.tbo - record.tsn })));
});

router.patch("/life-components/:id", async (req, res): Promise<void> => {
  const params = UpdateLifeComponentParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateLifeComponentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [record] = await db.update(lifeComponentsTable).set(parsed.data).where(eq(lifeComponentsTable.id, params.data.id)).returning();
  if (!record) {
    res.status(404).json({ error: "Life component not found" });
    return;
  }
  logAction({ action: "update", entity: "life-components", entityId: record.id, entityLabel: record.componentName });
  res.json(UpdateLifeComponentResponse.parse(serializeDates({ ...record, remainingLife: record.tbo - record.tsn })));
});

router.delete("/life-components/:id", async (req, res): Promise<void> => {
  const params = GetLifeComponentParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const [record] = await db.delete(lifeComponentsTable).where(eq(lifeComponentsTable.id, params.data.id)).returning();
  if (!record) { res.status(404).json({ error: "Life component not found" }); return; }
  logAction({ action: "delete", entity: "life-components", entityId: record.id, entityLabel: record.componentName });
  res.status(204).end();
});

export default router;
