import { Router, type IRouter } from "express";
import healthRouter from "./health";
import dashboardRouter from "./dashboard";
import aircraftRouter from "./aircraft";
import flightRecordsRouter from "./flight-records";
import maintenanceRouter from "./maintenance";
import lifeComponentsRouter from "./life-components";
import safetyReportsRouter from "./safety-reports";
import alertsRouter from "./alerts";
import investigationsRouter from "./investigations";
import usersRouter from "./users";
import auditLogsRouter from "./audit-logs";

const router: IRouter = Router();

router.use(healthRouter);
router.use(dashboardRouter);
router.use(aircraftRouter);
router.use(flightRecordsRouter);
router.use(maintenanceRouter);
router.use(lifeComponentsRouter);
router.use(safetyReportsRouter);
router.use(alertsRouter);
router.use(investigationsRouter);
router.use(usersRouter);
router.use(auditLogsRouter);

export default router;
