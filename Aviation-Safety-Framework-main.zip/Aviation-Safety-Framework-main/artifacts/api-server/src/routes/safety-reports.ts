import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, safetyReportsTable, aircraftTable } from "@workspace/db";
import { serializeDates } from "../utils/serialize";
import { logAction } from "../utils/audit";
import {
  ListSafetyReportsQueryParams,
  ListSafetyReportsResponse,
  CreateSafetyReportBody,
  GetSafetyReportParams,
  GetSafetyReportResponse,
  UpdateSafetyReportParams,
  UpdateSafetyReportBody,
  UpdateSafetyReportResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const COLS = {
  id: safetyReportsTable.id,
  reportType: safetyReportsTable.reportType,
  workflowStatus: safetyReportsTable.workflowStatus,
  aircraftId: safetyReportsTable.aircraftId,
  reporterName: safetyReportsTable.reporterName,
  reporterContact: safetyReportsTable.reporterContact,
  reporterEmployeeId: safetyReportsTable.reporterEmployeeId,
  reporterDepartment: safetyReportsTable.reporterDepartment,
  reporterRole: safetyReportsTable.reporterRole,
  category: safetyReportsTable.category,
  severity: safetyReportsTable.severity,
  description: safetyReportsTable.description,
  location: safetyReportsTable.location,
  incidentDate: safetyReportsTable.incidentDate,
  status: safetyReportsTable.status,
  occurrenceType: safetyReportsTable.occurrenceType,
  flightPhase: safetyReportsTable.flightPhase,
  injuries: safetyReportsTable.injuries,
  damage: safetyReportsTable.damage,
  hazardType: safetyReportsTable.hazardType,
  riskLevel: safetyReportsTable.riskLevel,
  contributingFactors: safetyReportsTable.contributingFactors,
  immediateActions: safetyReportsTable.immediateActions,
  fsrRecommendation: safetyReportsTable.fsrRecommendation,
  dfsrRecommendation: safetyReportsTable.dfsrRecommendation,
  correctiveAction: safetyReportsTable.correctiveAction,
  recommendations: safetyReportsTable.recommendations,
  createdAt: safetyReportsTable.createdAt,
};

router.get("/safety-reports", async (req, res): Promise<void> => {
  const query = ListSafetyReportsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const allRecords = await db
    .select({ ...COLS, aircraftRegistration: aircraftTable.registrationNo })
    .from(safetyReportsTable)
    .leftJoin(aircraftTable, eq(safetyReportsTable.aircraftId, aircraftTable.id))
    .orderBy(desc(safetyReportsTable.createdAt));

  let filtered = allRecords;
  if (query.data.status) filtered = filtered.filter(r => r.status === query.data.status);
  if (query.data.severity) filtered = filtered.filter(r => r.severity === query.data.severity);
  if (query.data.reportType) filtered = filtered.filter(r => r.reportType === query.data.reportType);
  if (query.data.workflowStatus) filtered = filtered.filter(r => r.workflowStatus === query.data.workflowStatus);

  res.json(ListSafetyReportsResponse.parse(serializeDates(filtered)));
});

router.post("/safety-reports", async (req, res): Promise<void> => {
  const parsed = CreateSafetyReportBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [record] = await db.insert(safetyReportsTable).values(parsed.data).returning();
  let aircraftRegistration = null;
  if (record.aircraftId) {
    const [aircraft] = await db.select().from(aircraftTable).where(eq(aircraftTable.id, record.aircraftId));
    aircraftRegistration = aircraft?.registrationNo ?? null;
  }
  logAction({ action: "create", entity: "safety-reports", entityId: record.id, entityLabel: `${record.reportType} · ${record.category} · ${record.severity}` });
  res.status(201).json(GetSafetyReportResponse.parse(serializeDates({ ...record, aircraftRegistration })));
});

router.get("/safety-reports/:id", async (req, res): Promise<void> => {
  const params = GetSafetyReportParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [record] = await db
    .select({ ...COLS, aircraftRegistration: aircraftTable.registrationNo })
    .from(safetyReportsTable)
    .leftJoin(aircraftTable, eq(safetyReportsTable.aircraftId, aircraftTable.id))
    .where(eq(safetyReportsTable.id, params.data.id));
  if (!record) {
    res.status(404).json({ error: "Safety report not found" });
    return;
  }
  res.json(GetSafetyReportResponse.parse(serializeDates(record)));
});

router.patch("/safety-reports/:id", async (req, res): Promise<void> => {
  const params = UpdateSafetyReportParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateSafetyReportBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [record] = await db.update(safetyReportsTable).set(parsed.data).where(eq(safetyReportsTable.id, params.data.id)).returning();
  if (!record) {
    res.status(404).json({ error: "Safety report not found" });
    return;
  }
  logAction({ action: "update", entity: "safety-reports", entityId: record.id, entityLabel: `${record.reportType} · ${record.category}` });
  res.json(UpdateSafetyReportResponse.parse(serializeDates(record)));
});

router.delete("/safety-reports/:id", async (req, res): Promise<void> => {
  const params = GetSafetyReportParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const [record] = await db.delete(safetyReportsTable).where(eq(safetyReportsTable.id, params.data.id)).returning();
  if (!record) { res.status(404).json({ error: "Safety report not found" }); return; }
  logAction({ action: "delete", entity: "safety-reports", entityId: record.id, entityLabel: `${record.reportType} · ${record.category}` });
  res.status(204).end();
});

export default router;
