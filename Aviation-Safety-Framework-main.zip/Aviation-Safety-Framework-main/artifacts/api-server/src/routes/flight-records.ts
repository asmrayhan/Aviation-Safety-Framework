import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, flightRecordsTable, aircraftTable } from "@workspace/db";
import { serializeDates } from "../utils/serialize";
import { logAction } from "../utils/audit";
import {
  ListFlightRecordsQueryParams,
  ListFlightRecordsResponse,
  CreateFlightRecordBody,
  GetFlightRecordParams,
  GetFlightRecordResponse,
  UpdateFlightRecordParams,
  UpdateFlightRecordBody,
  UpdateFlightRecordResponse,
  DeleteFlightRecordParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/flight-records", async (req, res): Promise<void> => {
  const query = ListFlightRecordsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const allRecords = await db
    .select({
      id: flightRecordsTable.id,
      aircraftId: flightRecordsTable.aircraftId,
      pilotName: flightRecordsTable.pilotName,
      flightDate: flightRecordsTable.flightDate,
      dailyFlyingHrs: flightRecordsTable.dailyFlyingHrs,
      dailyEngineHrs: flightRecordsTable.dailyEngineHrs,
      dailyLandings: flightRecordsTable.dailyLandings,
      route: flightRecordsTable.route,
      notes: flightRecordsTable.notes,
      createdAt: flightRecordsTable.createdAt,
      aircraftRegistration: aircraftTable.registrationNo,
    })
    .from(flightRecordsTable)
    .leftJoin(aircraftTable, eq(flightRecordsTable.aircraftId, aircraftTable.id))
    .orderBy(desc(flightRecordsTable.flightDate));

  const filtered = query.data.aircraftId
    ? allRecords.filter(r => r.aircraftId === query.data.aircraftId)
    : allRecords;

  res.json(ListFlightRecordsResponse.parse(serializeDates(filtered)));
});

router.post("/flight-records", async (req, res): Promise<void> => {
  const parsed = CreateFlightRecordBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [record] = await db.insert(flightRecordsTable).values(parsed.data).returning();

  // Update aircraft totals
  const [aircraft] = await db.select().from(aircraftTable).where(eq(aircraftTable.id, record.aircraftId));
  if (aircraft) {
    await db.update(aircraftTable).set({
      totalFlyingHrs: aircraft.totalFlyingHrs + record.dailyFlyingHrs,
      totalEngineHrs: aircraft.totalEngineHrs + record.dailyEngineHrs,
      totalLandings: aircraft.totalLandings + record.dailyLandings,
    }).where(eq(aircraftTable.id, record.aircraftId));
  }

  logAction({ action: "create", entity: "flight-records", entityId: record.id, entityLabel: `${aircraft?.registrationNo ?? record.aircraftId} · ${record.flightDate}` });
  const result = { ...record, aircraftRegistration: aircraft?.registrationNo ?? null };
  res.status(201).json(GetFlightRecordResponse.parse(serializeDates(result)));
});

router.get("/flight-records/:id", async (req, res): Promise<void> => {
  const params = GetFlightRecordParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [record] = await db
    .select({
      id: flightRecordsTable.id,
      aircraftId: flightRecordsTable.aircraftId,
      pilotName: flightRecordsTable.pilotName,
      flightDate: flightRecordsTable.flightDate,
      dailyFlyingHrs: flightRecordsTable.dailyFlyingHrs,
      dailyEngineHrs: flightRecordsTable.dailyEngineHrs,
      dailyLandings: flightRecordsTable.dailyLandings,
      route: flightRecordsTable.route,
      notes: flightRecordsTable.notes,
      createdAt: flightRecordsTable.createdAt,
      aircraftRegistration: aircraftTable.registrationNo,
    })
    .from(flightRecordsTable)
    .leftJoin(aircraftTable, eq(flightRecordsTable.aircraftId, aircraftTable.id))
    .where(eq(flightRecordsTable.id, params.data.id));

  if (!record) {
    res.status(404).json({ error: "Flight record not found" });
    return;
  }

  res.json(GetFlightRecordResponse.parse(serializeDates(record)));
});

router.patch("/flight-records/:id", async (req, res): Promise<void> => {
  const params = UpdateFlightRecordParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateFlightRecordBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [record] = await db.update(flightRecordsTable).set(parsed.data).where(eq(flightRecordsTable.id, params.data.id)).returning();
  if (!record) {
    res.status(404).json({ error: "Flight record not found" });
    return;
  }
  logAction({ action: "update", entity: "flight-records", entityId: record.id, entityLabel: record.flightDate });
  res.json(UpdateFlightRecordResponse.parse(serializeDates(record)));
});

router.delete("/flight-records/:id", async (req, res): Promise<void> => {
  const params = DeleteFlightRecordParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [record] = await db.delete(flightRecordsTable).where(eq(flightRecordsTable.id, params.data.id)).returning();
  if (!record) {
    res.status(404).json({ error: "Flight record not found" });
    return;
  }
  logAction({ action: "delete", entity: "flight-records", entityId: record.id, entityLabel: record.flightDate });
  res.sendStatus(204);
});

export default router;
