import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, alertsTable, aircraftTable } from "@workspace/db";
import { serializeDates } from "../utils/serialize";
import { logAction } from "../utils/audit";
import {
  ListAlertsQueryParams,
  ListAlertsResponse,
  CreateAlertBody,
  MarkAlertReadParams,
  MarkAlertReadResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/alerts", async (req, res): Promise<void> => {
  const query = ListAlertsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const allAlerts = await db
    .select({
      id: alertsTable.id,
      aircraftId: alertsTable.aircraftId,
      alertType: alertsTable.alertType,
      message: alertsTable.message,
      severity: alertsTable.severity,
      isRead: alertsTable.isRead,
      createdAt: alertsTable.createdAt,
      aircraftRegistration: aircraftTable.registrationNo,
    })
    .from(alertsTable)
    .leftJoin(aircraftTable, eq(alertsTable.aircraftId, aircraftTable.id))
    .orderBy(desc(alertsTable.createdAt));

  const filtered = query.data.isRead !== undefined
    ? allAlerts.filter(a => a.isRead === query.data.isRead)
    : allAlerts;

  res.json(ListAlertsResponse.parse(serializeDates(filtered)));
});

router.post("/alerts", async (req, res): Promise<void> => {
  const parsed = CreateAlertBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [alert] = await db.insert(alertsTable).values(parsed.data).returning();
  let aircraftRegistration = null;
  if (alert.aircraftId) {
    const [aircraft] = await db.select().from(aircraftTable).where(eq(aircraftTable.id, alert.aircraftId));
    aircraftRegistration = aircraft?.registrationNo ?? null;
  }
  logAction({ action: "create", entity: "alerts", entityId: alert.id, entityLabel: alert.alertType });
  res.status(201).json(MarkAlertReadResponse.parse(serializeDates({ ...alert, aircraftRegistration })));
});

router.patch("/alerts/:id/read", async (req, res): Promise<void> => {
  const params = MarkAlertReadParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [alert] = await db.update(alertsTable).set({ isRead: true }).where(eq(alertsTable.id, params.data.id)).returning();
  if (!alert) {
    res.status(404).json({ error: "Alert not found" });
    return;
  }
  let aircraftRegistration = null;
  if (alert.aircraftId) {
    const [aircraft] = await db.select().from(aircraftTable).where(eq(aircraftTable.id, alert.aircraftId));
    aircraftRegistration = aircraft?.registrationNo ?? null;
  }
  res.json(MarkAlertReadResponse.parse(serializeDates({ ...alert, aircraftRegistration })));
});

router.delete("/alerts/:id", async (req, res): Promise<void> => {
  const params = MarkAlertReadParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const [alert] = await db.delete(alertsTable).where(eq(alertsTable.id, params.data.id)).returning();
  if (!alert) { res.status(404).json({ error: "Alert not found" }); return; }
  logAction({ action: "delete", entity: "alerts", entityId: alert.id, entityLabel: alert.alertType });
  res.status(204).end();
});

export default router;
