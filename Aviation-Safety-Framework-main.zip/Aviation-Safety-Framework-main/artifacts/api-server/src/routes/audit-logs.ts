import { Router, type IRouter } from "express";
import { eq, desc, and, lt, inArray, count, sql } from "drizzle-orm";
import { db, auditLogsTable, logSettingsTable } from "@workspace/db";
import { serializeDates } from "../utils/serialize";

const router: IRouter = Router();

// Initialize settings row (singleton) and start auto-delete scheduler
async function initSettings() {
  const [existing] = await db.select().from(logSettingsTable).limit(1);
  if (!existing) {
    await db.insert(logSettingsTable).values({ autoDeleteDays: null });
  }
}

async function runAutoDelete() {
  const [settings] = await db.select().from(logSettingsTable).limit(1);
  if (!settings?.autoDeleteDays) return;
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - settings.autoDeleteDays);
  await db.delete(auditLogsTable).where(lt(auditLogsTable.createdAt, cutoff));
}

// Run on startup and every hour
initSettings().catch(() => {});
setInterval(() => { runAutoDelete().catch(() => {}); }, 60 * 60 * 1000);

// GET /audit-logs?page=1&limit=50&entity=&action=
router.get("/audit-logs", async (req, res): Promise<void> => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 50));
  const offset = (page - 1) * limit;
  const entityFilter = req.query.entity as string | undefined;
  const actionFilter = req.query.action as string | undefined;

  const conditions = [];
  if (entityFilter) conditions.push(eq(auditLogsTable.entity, entityFilter));
  if (actionFilter) conditions.push(eq(auditLogsTable.action, actionFilter));

  const where = conditions.length > 0 ? and(...conditions) : undefined;

  const [rows, totalResult] = await Promise.all([
    db.select().from(auditLogsTable)
      .where(where)
      .orderBy(desc(auditLogsTable.createdAt))
      .limit(limit)
      .offset(offset),
    db.select({ count: count() }).from(auditLogsTable).where(where),
  ]);

  const total = Number(totalResult[0]?.count ?? 0);
  res.json({
    data: serializeDates(rows),
    total,
    page,
    limit,
    totalPages: Math.ceil(total / limit),
  });
});

// DELETE /audit-logs/bulk  (body: { ids: number[] })
router.delete("/audit-logs/bulk", async (req, res): Promise<void> => {
  const ids = req.body?.ids;
  if (!Array.isArray(ids) || ids.length === 0) {
    res.status(400).json({ error: "ids must be a non-empty array" });
    return;
  }
  const numIds = ids.map(Number).filter((n) => !isNaN(n));
  await db.delete(auditLogsTable).where(inArray(auditLogsTable.id, numIds));
  res.json({ deleted: numIds.length });
});

// DELETE /audit-logs/all  — clear all logs
router.delete("/audit-logs/all", async (_req, res): Promise<void> => {
  const result = await db.delete(auditLogsTable).returning({ id: auditLogsTable.id });
  res.json({ deleted: result.length });
});

// DELETE /audit-logs/:id
router.delete("/audit-logs/:id", async (req, res): Promise<void> => {
  const id = Number(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [row] = await db.delete(auditLogsTable).where(eq(auditLogsTable.id, id)).returning();
  if (!row) { res.status(404).json({ error: "Log not found" }); return; }
  res.status(204).end();
});

// GET /audit-logs/settings
router.get("/audit-logs/settings", async (_req, res): Promise<void> => {
  const [settings] = await db.select().from(logSettingsTable).limit(1);
  res.json({ autoDeleteDays: settings?.autoDeleteDays ?? null });
});

// PUT /audit-logs/settings  (body: { autoDeleteDays: number | null })
router.put("/audit-logs/settings", async (req, res): Promise<void> => {
  const { autoDeleteDays } = req.body ?? {};
  const days = autoDeleteDays === null ? null : Number(autoDeleteDays);
  if (days !== null && (isNaN(days) || days <= 0)) {
    res.status(400).json({ error: "autoDeleteDays must be a positive integer or null" });
    return;
  }

  const [existing] = await db.select().from(logSettingsTable).limit(1);
  if (existing) {
    await db.update(logSettingsTable).set({ autoDeleteDays: days });
  } else {
    await db.insert(logSettingsTable).values({ autoDeleteDays: days });
  }

  // Immediately run auto-delete if a period was set
  if (days !== null) runAutoDelete().catch(() => {});

  res.json({ autoDeleteDays: days });
});

// GET /audit-logs/stats  (for dashboard badges)
router.get("/audit-logs/stats", async (_req, res): Promise<void> => {
  const result = await db
    .select({ entity: auditLogsTable.entity, action: auditLogsTable.action, cnt: sql<number>`count(*)::int` })
    .from(auditLogsTable)
    .groupBy(auditLogsTable.entity, auditLogsTable.action);
  res.json(result);
});

export default router;
