import { Router, type IRouter } from "express";
import { desc, eq, gte } from "drizzle-orm";
import { db, aircraftTable, alertsTable, maintenanceTable, investigationsTable, safetyReportsTable, flightRecordsTable } from "@workspace/db";
import { GetDashboardSummaryResponse } from "@workspace/api-zod";
import { serializeDates } from "../utils/serialize";

const router: IRouter = Router();

router.get("/dashboard/summary", async (_req, res): Promise<void> => {
  const now = new Date();
  const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split("T")[0];
  const today = now.toISOString().split("T")[0];

  const [aircraft, unreadAlerts, pendingMaint, openInvestigations, openReports, monthFlights, recentAlerts, upcomingMaintenance] = await Promise.all([
    db.select().from(aircraftTable),
    db.select().from(alertsTable).where(eq(alertsTable.isRead, false)),
    db.select().from(maintenanceTable).where(eq(maintenanceTable.status, "pending")),
    db.select().from(investigationsTable).where(eq(investigationsTable.status, "open")),
    db.select().from(safetyReportsTable).where(eq(safetyReportsTable.status, "open")),
    db.select().from(flightRecordsTable).where(gte(flightRecordsTable.flightDate, thisMonthStart)),
    db.select({
      id: alertsTable.id,
      aircraftId: alertsTable.aircraftId,
      alertType: alertsTable.alertType,
      message: alertsTable.message,
      severity: alertsTable.severity,
      isRead: alertsTable.isRead,
      createdAt: alertsTable.createdAt,
      aircraftRegistration: aircraftTable.registrationNo,
    }).from(alertsTable).leftJoin(aircraftTable, eq(alertsTable.aircraftId, aircraftTable.id)).orderBy(desc(alertsTable.createdAt)).limit(5),
    db.select({
      id: maintenanceTable.id,
      aircraftId: maintenanceTable.aircraftId,
      engineerName: maintenanceTable.engineerName,
      maintenanceType: maintenanceTable.maintenanceType,
      description: maintenanceTable.description,
      status: maintenanceTable.status,
      scheduledDate: maintenanceTable.scheduledDate,
      completedDate: maintenanceTable.completedDate,
      nextDueDate: maintenanceTable.nextDueDate,
      findings: maintenanceTable.findings,
      createdAt: maintenanceTable.createdAt,
      aircraftRegistration: aircraftTable.registrationNo,
    }).from(maintenanceTable).leftJoin(aircraftTable, eq(maintenanceTable.aircraftId, aircraftTable.id)).where(gte(maintenanceTable.scheduledDate, today)).orderBy(maintenanceTable.scheduledDate).limit(5),
  ]);

  const totalFlightHoursThisMonth = monthFlights.reduce((sum, r) => sum + r.dailyFlyingHrs, 0);

  res.json(GetDashboardSummaryResponse.parse(serializeDates({
    totalAircraft: aircraft.length,
    activeAlerts: unreadAlerts.length,
    pendingMaintenance: pendingMaint.length,
    openInvestigations: openInvestigations.length,
    openSafetyReports: openReports.length,
    totalFlightHoursThisMonth,
    recentAlerts,
    upcomingMaintenance,
  })));
});

export default router;
