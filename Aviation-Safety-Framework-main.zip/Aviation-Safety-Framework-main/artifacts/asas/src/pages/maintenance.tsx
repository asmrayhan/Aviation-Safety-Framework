import { useState } from "react";
import { useListMaintenance, useCreateMaintenance, useUpdateMaintenance, useDeleteMaintenance, getListMaintenanceQueryKey, useListAircraft } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/layout";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type MaintenanceFormData = {
  aircraftId: number;
  engineerName?: string;
  maintenanceType: string;
  description: string;
  status: string;
  scheduledDate: string;
  completedDate?: string;
  nextDueDate?: string;
  findings?: string;
};

type MaintenanceRow = { id: number; aircraftId: number; aircraftRegistration?: string | null; engineerName?: string | null; maintenanceType: string; description: string; status: string; scheduledDate: string; completedDate?: string | null; nextDueDate?: string | null; findings?: string | null };

export default function Maintenance() {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<MaintenanceRow | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<MaintenanceRow | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const { data: records, isLoading } = useListMaintenance();
  const { data: aircraft } = useListAircraft();
  const createRecord = useCreateMaintenance();
  const updateRecord = useUpdateMaintenance();
  const deleteRecord = useDeleteMaintenance();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<MaintenanceFormData>({
    defaultValues: { status: "pending", scheduledDate: new Date().toISOString().split("T")[0] },
  });

  const filtered = (records ?? []).filter((r) => statusFilter === "all" || r.status === statusFilter);

  function openCreate() {
    setEditing(null);
    form.reset({ status: "pending", scheduledDate: new Date().toISOString().split("T")[0] });
    setOpen(true);
  }

  function openEdit(m: MaintenanceRow) {
    setEditing(m);
    form.reset({
      aircraftId: m.aircraftId,
      engineerName: m.engineerName ?? undefined,
      maintenanceType: m.maintenanceType,
      description: m.description,
      status: m.status,
      scheduledDate: m.scheduledDate,
      completedDate: m.completedDate ?? undefined,
      nextDueDate: m.nextDueDate ?? undefined,
      findings: m.findings ?? undefined,
    });
    setOpen(true);
  }

  function onSubmit(data: MaintenanceFormData) {
    const payload = { ...data, aircraftId: Number(data.aircraftId) };
    const invalidate = () => queryClient.invalidateQueries({ queryKey: getListMaintenanceQueryKey() });
    if (editing) {
      updateRecord.mutate({ id: editing.id, data: payload }, {
        onSuccess: () => { invalidate(); setOpen(false); toast({ title: "Maintenance record updated" }); },
        onError: () => toast({ title: "Failed to update record", variant: "destructive" }),
      });
    } else {
      createRecord.mutate({ data: payload }, {
        onSuccess: () => { invalidate(); setOpen(false); form.reset(); toast({ title: "Maintenance record created" }); },
        onError: () => toast({ title: "Failed to create record", variant: "destructive" }),
      });
    }
  }

  function handleStatusChange(id: number, status: string) {
    const completedDate = status === "completed" ? new Date().toISOString().split("T")[0] : undefined;
    updateRecord.mutate({ id, data: { status, ...(completedDate ? { completedDate } : {}) } }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListMaintenanceQueryKey() }),
    });
  }

  function confirmDelete() {
    if (!deleteTarget) return;
    deleteRecord.mutate({ id: deleteTarget.id }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListMaintenanceQueryKey() }); setDeleteTarget(null); toast({ title: "Record deleted" }); },
      onError: () => toast({ title: "Failed to delete record", variant: "destructive" }),
    });
  }

  return (
    <div className="flex-1 overflow-auto">
      <PageHeader
        title="Maintenance"
        subtitle="Scheduled and completed maintenance records"
        action={<Button size="sm" onClick={openCreate}><Plus className="w-4 h-4 mr-1" /> Add Record</Button>}
      />
      <div className="p-6 space-y-4">
        <div className="flex gap-2">
          {["all", "pending", "in-progress", "completed"].map((s) => (
            <Button key={s} size="sm" variant={statusFilter === s ? "default" : "outline"} onClick={() => setStatusFilter(s)} className="capitalize">
              {s === "all" ? "All" : s}
            </Button>
          ))}
        </div>

        {isLoading ? (
          <div className="space-y-2">{[...Array(5)].map((_, i) => <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />)}</div>
        ) : (
          <div className="space-y-2">
            {filtered.length === 0 && <p className="text-muted-foreground text-center py-10">No maintenance records found</p>}
            {filtered.map((m) => (
              <div key={m.id} className="bg-card border border-border rounded-lg p-4 flex items-start gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <StatusBadge value={m.status} />
                    <span className="font-semibold text-sm text-foreground">{m.maintenanceType}</span>
                    {m.aircraftRegistration && <span className="font-mono text-xs text-primary">{m.aircraftRegistration}</span>}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{m.description}</p>
                  <div className="flex gap-4 mt-1.5 text-xs text-muted-foreground flex-wrap">
                    <span>Scheduled: <span className="text-foreground">{m.scheduledDate}</span></span>
                    {m.completedDate && <span>Completed: <span className="text-foreground">{m.completedDate}</span></span>}
                    {m.nextDueDate && <span>Next due: <span className="text-foreground">{m.nextDueDate}</span></span>}
                    {m.engineerName && <span>Engineer: <span className="text-foreground">{m.engineerName}</span></span>}
                  </div>
                  {m.findings && <p className="text-xs text-orange-600 mt-1">Findings: {m.findings}</p>}
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <Select value={m.status} onValueChange={(v) => handleStatusChange(m.id, v)}>
                    <SelectTrigger className="w-36 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="in-progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-foreground" onClick={() => openEdit(m)}><Pencil className="w-3.5 h-3.5" /></Button>
                  <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-destructive" onClick={() => setDeleteTarget(m)}><Trash2 className="w-3.5 h-3.5" /></Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Edit Maintenance Record" : "Add Maintenance Record"}</DialogTitle></DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label>Aircraft *</Label>
                <Select value={form.watch("aircraftId") ? String(form.watch("aircraftId")) : ""} onValueChange={(v) => form.setValue("aircraftId", Number(v))}>
                  <SelectTrigger><SelectValue placeholder="Select aircraft" /></SelectTrigger>
                  <SelectContent>{(aircraft ?? []).map((a) => <SelectItem key={a.id} value={String(a.id)}>{a.registrationNo}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Maintenance Type *</Label>
                <Input {...form.register("maintenanceType", { required: true })} placeholder="A-Check" />
              </div>
              <div>
                <Label>Status</Label>
                <Select value={form.watch("status")} onValueChange={(v) => form.setValue("status", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-2">
                <Label>Description *</Label>
                <Input {...form.register("description", { required: true })} />
              </div>
              <div>
                <Label>Scheduled Date *</Label>
                <Input type="date" {...form.register("scheduledDate", { required: true })} />
              </div>
              <div>
                <Label>Completed Date</Label>
                <Input type="date" {...form.register("completedDate")} />
              </div>
              <div>
                <Label>Next Due Date</Label>
                <Input type="date" {...form.register("nextDueDate")} />
              </div>
              <div>
                <Label>Engineer Name</Label>
                <Input {...form.register("engineerName")} />
              </div>
              <div className="col-span-2">
                <Label>Findings</Label>
                <Input {...form.register("findings")} />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={createRecord.isPending || updateRecord.isPending}>
                {createRecord.isPending || updateRecord.isPending ? "Saving..." : editing ? "Save Changes" : "Save"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Delete Maintenance Record</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Delete <span className="font-semibold text-foreground">{deleteTarget?.maintenanceType}</span> for <span className="font-mono text-foreground">{deleteTarget?.aircraftRegistration}</span>? This cannot be undone.</p>
          <div className="flex justify-end gap-2 mt-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleteRecord.isPending}>{deleteRecord.isPending ? "Deleting..." : "Delete"}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
