import { useState } from "react";
import { useListFlightRecords, useCreateFlightRecord, useUpdateFlightRecord, useDeleteFlightRecord, getListFlightRecordsQueryKey, useListAircraft } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { Plus, Trash2, Pencil } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type FlightFormData = {
  aircraftId: number;
  pilotName?: string;
  flightDate: string;
  dailyFlyingHrs: number;
  dailyEngineHrs: number;
  dailyLandings: number;
  route?: string;
  notes?: string;
};

type FlightRow = { id: number; aircraftId: number; aircraftRegistration?: string | null; pilotName?: string | null; flightDate: string; dailyFlyingHrs: number; dailyEngineHrs: number; dailyLandings: number; route?: string | null; notes?: string | null };

export default function FlightRecords() {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<FlightRow | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<FlightRow | null>(null);
  const { data: records, isLoading } = useListFlightRecords();
  const { data: aircraft } = useListAircraft();
  const createRecord = useCreateFlightRecord();
  const updateRecord = useUpdateFlightRecord();
  const deleteRecord = useDeleteFlightRecord();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<FlightFormData>({
    defaultValues: { flightDate: new Date().toISOString().split("T")[0], dailyFlyingHrs: 0, dailyEngineHrs: 0, dailyLandings: 0 },
  });

  function openCreate() {
    setEditing(null);
    form.reset({ flightDate: new Date().toISOString().split("T")[0], dailyFlyingHrs: 0, dailyEngineHrs: 0, dailyLandings: 0 });
    setOpen(true);
  }

  function openEdit(r: FlightRow) {
    setEditing(r);
    form.reset({
      aircraftId: r.aircraftId,
      pilotName: r.pilotName ?? undefined,
      flightDate: r.flightDate,
      dailyFlyingHrs: r.dailyFlyingHrs,
      dailyEngineHrs: r.dailyEngineHrs,
      dailyLandings: r.dailyLandings,
      route: r.route ?? undefined,
      notes: r.notes ?? undefined,
    });
    setOpen(true);
  }

  function onSubmit(data: FlightFormData) {
    const payload = { ...data, aircraftId: Number(data.aircraftId) };
    const invalidate = () => queryClient.invalidateQueries({ queryKey: getListFlightRecordsQueryKey() });
    if (editing) {
      updateRecord.mutate({ id: editing.id, data: payload }, {
        onSuccess: () => { invalidate(); setOpen(false); toast({ title: "Flight record updated" }); },
        onError: () => toast({ title: "Failed to update record", variant: "destructive" }),
      });
    } else {
      createRecord.mutate({ data: payload }, {
        onSuccess: () => { invalidate(); setOpen(false); form.reset(); toast({ title: "Flight record created" }); },
        onError: () => toast({ title: "Failed to create record", variant: "destructive" }),
      });
    }
  }

  function confirmDelete() {
    if (!deleteTarget) return;
    deleteRecord.mutate({ id: deleteTarget.id }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListFlightRecordsQueryKey() }); setDeleteTarget(null); toast({ title: "Record deleted" }); },
    });
  }

  return (
    <div className="flex-1 overflow-auto">
      <PageHeader
        title="Flight Records"
        subtitle="Aircraft utilization — daily hours and landings"
        action={<Button size="sm" onClick={openCreate}><Plus className="w-4 h-4 mr-1" /> Add Record</Button>}
      />
      <div className="p-6">
        {isLoading ? (
          <div className="space-y-2">{[...Array(5)].map((_, i) => <div key={i} className="h-12 bg-muted animate-pulse rounded" />)}</div>
        ) : (
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  <th className="text-left px-4 py-2.5 font-medium text-muted-foreground">Aircraft</th>
                  <th className="text-left px-4 py-2.5 font-medium text-muted-foreground">Date</th>
                  <th className="text-left px-4 py-2.5 font-medium text-muted-foreground">Pilot</th>
                  <th className="text-left px-4 py-2.5 font-medium text-muted-foreground">Route</th>
                  <th className="text-right px-4 py-2.5 font-medium text-muted-foreground">Flying Hrs</th>
                  <th className="text-right px-4 py-2.5 font-medium text-muted-foreground">Engine Hrs</th>
                  <th className="text-right px-4 py-2.5 font-medium text-muted-foreground">Landings</th>
                  <th className="px-4 py-2.5"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {(records ?? []).length === 0 && <tr><td colSpan={8} className="text-center py-10 text-muted-foreground">No flight records found</td></tr>}
                {(records ?? []).map((r) => (
                  <tr key={r.id} className="hover:bg-muted/20">
                    <td className="px-4 py-3 font-mono text-primary font-semibold">{r.aircraftRegistration ?? r.aircraftId}</td>
                    <td className="px-4 py-3 text-foreground">{r.flightDate}</td>
                    <td className="px-4 py-3 text-muted-foreground">{r.pilotName ?? "—"}</td>
                    <td className="px-4 py-3 text-muted-foreground">{r.route ?? "—"}</td>
                    <td className="px-4 py-3 text-right font-mono">{r.dailyFlyingHrs.toFixed(1)}</td>
                    <td className="px-4 py-3 text-right font-mono">{r.dailyEngineHrs.toFixed(1)}</td>
                    <td className="px-4 py-3 text-right font-mono">{r.dailyLandings}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 justify-end">
                        <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-foreground" onClick={() => openEdit(r)}><Pencil className="w-3.5 h-3.5" /></Button>
                        <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-destructive" onClick={() => setDeleteTarget(r)}><Trash2 className="w-3.5 h-3.5" /></Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Edit Flight Record" : "Add Flight Record"}</DialogTitle></DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label>Aircraft *</Label>
                <Select value={form.watch("aircraftId") ? String(form.watch("aircraftId")) : ""} onValueChange={(v) => form.setValue("aircraftId", Number(v))}>
                  <SelectTrigger><SelectValue placeholder="Select aircraft" /></SelectTrigger>
                  <SelectContent>
                    {(aircraft ?? []).map((a) => <SelectItem key={a.id} value={String(a.id)}>{a.registrationNo} — {a.manufacturer} {a.model}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Date *</Label>
                <Input type="date" {...form.register("flightDate", { required: true })} />
              </div>
              <div>
                <Label>Pilot Name</Label>
                <Input {...form.register("pilotName")} />
              </div>
              <div>
                <Label>Daily Flying Hrs *</Label>
                <Input type="number" step="0.1" {...form.register("dailyFlyingHrs", { valueAsNumber: true })} />
              </div>
              <div>
                <Label>Daily Engine Hrs *</Label>
                <Input type="number" step="0.1" {...form.register("dailyEngineHrs", { valueAsNumber: true })} />
              </div>
              <div>
                <Label>Daily Landings *</Label>
                <Input type="number" {...form.register("dailyLandings", { valueAsNumber: true })} />
              </div>
              <div>
                <Label>Route</Label>
                <Input {...form.register("route")} placeholder="DAC-CGP-DAC" />
              </div>
              <div className="col-span-2">
                <Label>Notes</Label>
                <Input {...form.register("notes")} />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={createRecord.isPending || updateRecord.isPending}>
                {createRecord.isPending || updateRecord.isPending ? "Saving..." : editing ? "Save Changes" : "Save"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Delete Flight Record</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Delete the flight record for <span className="font-semibold text-foreground">{deleteTarget?.aircraftRegistration}</span> on <span className="font-semibold text-foreground">{deleteTarget?.flightDate}</span>? This cannot be undone.</p>
          <div className="flex justify-end gap-2 mt-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleteRecord.isPending}>{deleteRecord.isPending ? "Deleting..." : "Delete"}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
