import { useState } from "react";
import { useListAircraft, useCreateAircraft, useUpdateAircraft, useDeleteAircraft, getListAircraftQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/layout";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { Link } from "wouter";
import { Plus, Search, Plane, Pencil, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type AircraftFormData = {
  registrationNo: string;
  aircraftType: string;
  manufacturer: string;
  model: string;
  yearOfManufacture?: number;
  status: string;
  totalFlyingHrs: number;
  totalEngineHrs: number;
  totalLandings: number;
  notes?: string;
};

type AircraftRow = { id: number; registrationNo: string; aircraftType: string; manufacturer: string; model: string; yearOfManufacture?: number | null; status: string; totalFlyingHrs: number; totalEngineHrs: number; totalLandings: number; notes?: string | null };

export default function Aircraft() {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<AircraftRow | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<AircraftRow | null>(null);
  const [search, setSearch] = useState("");
  const { data: aircraft, isLoading } = useListAircraft();
  const createAircraft = useCreateAircraft();
  const updateAircraft = useUpdateAircraft();
  const deleteAircraft = useDeleteAircraft();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<AircraftFormData>({
    defaultValues: { status: "active", totalFlyingHrs: 0, totalEngineHrs: 0, totalLandings: 0 },
  });

  const filtered = (aircraft ?? []).filter(
    (a) =>
      a.registrationNo.toLowerCase().includes(search.toLowerCase()) ||
      a.manufacturer.toLowerCase().includes(search.toLowerCase()) ||
      a.model.toLowerCase().includes(search.toLowerCase())
  );

  function openCreate() {
    setEditing(null);
    form.reset({ status: "active", totalFlyingHrs: 0, totalEngineHrs: 0, totalLandings: 0 });
    setOpen(true);
  }

  function openEdit(a: AircraftRow) {
    setEditing(a);
    form.reset({
      registrationNo: a.registrationNo,
      aircraftType: a.aircraftType,
      manufacturer: a.manufacturer,
      model: a.model,
      yearOfManufacture: a.yearOfManufacture ?? undefined,
      status: a.status,
      totalFlyingHrs: a.totalFlyingHrs,
      totalEngineHrs: a.totalEngineHrs,
      totalLandings: a.totalLandings,
      notes: a.notes ?? undefined,
    });
    setOpen(true);
  }

  function onSubmit(data: AircraftFormData) {
    const payload = { ...data, yearOfManufacture: data.yearOfManufacture ? Number(data.yearOfManufacture) : undefined };
    const invalidate = () => queryClient.invalidateQueries({ queryKey: getListAircraftQueryKey() });
    if (editing) {
      updateAircraft.mutate({ id: editing.id, data: payload }, {
        onSuccess: () => { invalidate(); setOpen(false); toast({ title: "Aircraft updated" }); },
        onError: () => toast({ title: "Failed to update aircraft", variant: "destructive" }),
      });
    } else {
      createAircraft.mutate({ data: payload }, {
        onSuccess: () => { invalidate(); setOpen(false); form.reset(); toast({ title: "Aircraft registered" }); },
        onError: () => toast({ title: "Failed to register aircraft", variant: "destructive" }),
      });
    }
  }

  function confirmDelete() {
    if (!deleteTarget) return;
    deleteAircraft.mutate({ id: deleteTarget.id }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListAircraftQueryKey() }); setDeleteTarget(null); toast({ title: "Aircraft removed" }); },
      onError: () => toast({ title: "Failed to delete aircraft", variant: "destructive" }),
    });
  }

  return (
    <div className="flex-1 overflow-auto">
      <PageHeader
        title="Aircraft Fleet"
        subtitle={`${(aircraft ?? []).length} aircraft registered`}
        action={<Button size="sm" onClick={openCreate}><Plus className="w-4 h-4 mr-1" /> Add Aircraft</Button>}
      />
      <div className="p-6">
        <div className="mb-4 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Search by registration, manufacturer or model..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>

        {isLoading ? (
          <div className="space-y-2">{[...Array(5)].map((_, i) => <div key={i} className="h-14 bg-muted animate-pulse rounded-lg" />)}</div>
        ) : (
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  <th className="text-left px-4 py-2.5 font-medium text-muted-foreground">Registration</th>
                  <th className="text-left px-4 py-2.5 font-medium text-muted-foreground">Type / Model</th>
                  <th className="text-left px-4 py-2.5 font-medium text-muted-foreground">Status</th>
                  <th className="text-right px-4 py-2.5 font-medium text-muted-foreground">Flying Hrs</th>
                  <th className="text-right px-4 py-2.5 font-medium text-muted-foreground">Engine Hrs</th>
                  <th className="text-right px-4 py-2.5 font-medium text-muted-foreground">Landings</th>
                  <th className="px-4 py-2.5"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.length === 0 && <tr><td colSpan={7} className="text-center py-10 text-muted-foreground">No aircraft found</td></tr>}
                {filtered.map((a) => (
                  <tr key={a.id} className="hover:bg-muted/20 transition-colors">
                    <td className="px-4 py-3">
                      <Link href={`/aircraft/${a.id}`} className="font-mono font-semibold text-primary hover:underline flex items-center gap-1.5">
                        <Plane className="w-3.5 h-3.5" />{a.registrationNo}
                      </Link>
                    </td>
                    <td className="px-4 py-3">
                      <p className="font-medium text-foreground">{a.manufacturer} {a.model}</p>
                      <p className="text-xs text-muted-foreground">{a.aircraftType}{a.yearOfManufacture ? ` · ${a.yearOfManufacture}` : ""}</p>
                    </td>
                    <td className="px-4 py-3"><StatusBadge value={a.status} /></td>
                    <td className="px-4 py-3 text-right font-mono text-sm">{a.totalFlyingHrs.toFixed(1)}</td>
                    <td className="px-4 py-3 text-right font-mono text-sm">{a.totalEngineHrs.toFixed(1)}</td>
                    <td className="px-4 py-3 text-right font-mono text-sm">{a.totalLandings.toLocaleString()}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 justify-end">
                        <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-foreground" onClick={() => openEdit(a)}><Pencil className="w-3.5 h-3.5" /></Button>
                        <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-destructive" onClick={() => setDeleteTarget(a)}><Trash2 className="w-3.5 h-3.5" /></Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Edit Aircraft" : "Register Aircraft"}</DialogTitle></DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Registration No *</Label>
                <Input {...form.register("registrationNo", { required: true })} placeholder="S2-XXX" />
              </div>
              <div>
                <Label>Status</Label>
                <Select value={form.watch("status")} onValueChange={(v) => form.setValue("status", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="maintenance">In Maintenance</SelectItem>
                    <SelectItem value="grounded">Grounded</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Aircraft Type *</Label>
                <Input {...form.register("aircraftType", { required: true })} placeholder="Narrow-body jet" />
              </div>
              <div>
                <Label>Manufacturer *</Label>
                <Input {...form.register("manufacturer", { required: true })} placeholder="Boeing" />
              </div>
              <div>
                <Label>Model *</Label>
                <Input {...form.register("model", { required: true })} placeholder="737-800" />
              </div>
              <div>
                <Label>Year of Manufacture</Label>
                <Input type="number" {...form.register("yearOfManufacture", { valueAsNumber: true })} placeholder="2018" />
              </div>
              <div>
                <Label>Total Flying Hrs</Label>
                <Input type="number" step="0.1" {...form.register("totalFlyingHrs", { valueAsNumber: true })} />
              </div>
              <div>
                <Label>Total Engine Hrs</Label>
                <Input type="number" step="0.1" {...form.register("totalEngineHrs", { valueAsNumber: true })} />
              </div>
              <div>
                <Label>Total Landings</Label>
                <Input type="number" {...form.register("totalLandings", { valueAsNumber: true })} />
              </div>
              <div>
                <Label>Notes</Label>
                <Input {...form.register("notes")} />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={createAircraft.isPending || updateAircraft.isPending}>
                {createAircraft.isPending || updateAircraft.isPending ? "Saving..." : editing ? "Save Changes" : "Register"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Delete Aircraft</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Are you sure you want to remove <span className="font-mono font-semibold text-foreground">{deleteTarget?.registrationNo}</span> from the fleet? This cannot be undone.</p>
          <div className="flex justify-end gap-2 mt-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleteAircraft.isPending}>
              {deleteAircraft.isPending ? "Deleting..." : "Delete"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
