import { useGetDashboardSummary } from "@workspace/api-client-react";
import { PageHeader } from "@/components/layout";
import { StatusBadge } from "@/components/status-badge";
import { FlightHoursChart } from "@/components/flight-hours-chart";
import { Link } from "wouter";
import { Plane, Bell, Wrench, AlertTriangle, Search, Clock, TrendingUp } from "lucide-react";

export default function Dashboard() {
  const { data: summary, isLoading } = useGetDashboardSummary();

  if (isLoading) {
    return (
      <div>
        <PageHeader title="Dashboard" subtitle="Fleet-wide safety overview" />
        <div className="p-6 grid grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-24 rounded-lg bg-muted animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  const stats = [
    { label: "Total Aircraft", value: summary?.totalAircraft ?? 0, icon: Plane, color: "text-primary", link: "/aircraft" },
    { label: "Active Alerts", value: summary?.activeAlerts ?? 0, icon: Bell, color: "text-destructive", link: "/alerts" },
    { label: "Pending Maintenance", value: summary?.pendingMaintenance ?? 0, icon: Wrench, color: "text-orange-500", link: "/maintenance" },
    { label: "Open Safety Reports", value: summary?.openSafetyReports ?? 0, icon: AlertTriangle, color: "text-yellow-600", link: "/safety-reports" },
    { label: "Open Investigations", value: summary?.openInvestigations ?? 0, icon: Search, color: "text-purple-600", link: "/investigations" },
    { label: "Flight Hrs (This Month)", value: (summary?.totalFlightHoursThisMonth ?? 0).toFixed(1), icon: TrendingUp, color: "text-green-600", link: "/flight-records" },
  ];

  return (
    <div className="flex-1 overflow-auto">
      <PageHeader title="Dashboard" subtitle="Fleet-wide safety overview" />
      <div className="p-6 space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {stats.map((stat) => (
            <Link
              key={stat.label}
              href={stat.link}
              data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, "-")}`}
              className="bg-card border border-border rounded-lg p-4 hover:border-primary/40 transition-colors cursor-pointer block"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-2xl font-bold text-foreground mt-1">{stat.value}</p>
                </div>
                <stat.icon className={`w-5 h-5 mt-0.5 ${stat.color}`} />
              </div>
            </Link>
          ))}
        </div>

        {/* Flight Hours Chart */}
        <FlightHoursChart />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Recent Alerts */}
          <div className="bg-card border border-border rounded-lg">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border">
              <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Bell className="w-4 h-4 text-destructive" />
                Recent Alerts
              </h2>
              <Link href="/alerts" className="text-xs text-primary hover:underline">View all</Link>
            </div>
            <div className="divide-y divide-border">
              {(summary?.recentAlerts?.length ?? 0) === 0 && (
                <p className="text-sm text-muted-foreground text-center py-6">No active alerts</p>
              )}
              {summary?.recentAlerts?.map((alert) => (
                <div key={alert.id} data-testid={`alert-row-${alert.id}`} className="px-4 py-3 flex items-start gap-3">
                  <StatusBadge value={alert.severity} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{alert.alertType}</p>
                    <p className="text-xs text-muted-foreground truncate mt-0.5">{alert.message}</p>
                    {alert.aircraftRegistration && (
                      <p className="text-xs text-primary mt-0.5">{alert.aircraftRegistration}</p>
                    )}
                  </div>
                  {!alert.isRead && <span className="w-2 h-2 rounded-full bg-primary flex-shrink-0 mt-1.5" />}
                </div>
              ))}
            </div>
          </div>

          {/* Upcoming Maintenance */}
          <div className="bg-card border border-border rounded-lg">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border">
              <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Clock className="w-4 h-4 text-orange-500" />
                Upcoming Maintenance
              </h2>
              <Link href="/maintenance" className="text-xs text-primary hover:underline">View all</Link>
            </div>
            <div className="divide-y divide-border">
              {(summary?.upcomingMaintenance?.length ?? 0) === 0 && (
                <p className="text-sm text-muted-foreground text-center py-6">No upcoming maintenance</p>
              )}
              {summary?.upcomingMaintenance?.map((m) => (
                <div key={m.id} data-testid={`maintenance-row-${m.id}`} className="px-4 py-3 flex items-start gap-3">
                  <StatusBadge value={m.status} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{m.maintenanceType}</p>
                    <p className="text-xs text-muted-foreground truncate">{m.description}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      {m.aircraftRegistration && <span className="text-xs text-primary">{m.aircraftRegistration}</span>}
                      <span className="text-xs text-muted-foreground">{m.scheduledDate}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
