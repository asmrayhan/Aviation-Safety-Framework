import { useState } from "react";
import { useListInvestigations, useCreateInvestigation, useUpdateInvestigation, useDeleteInvestigation, getListInvestigationsQueryKey, useListAircraft } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/layout";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { Plus, ChevronDown, ChevronUp, Pencil, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type InvestigationFormData = {
  aircraftId?: number;
  investigatorName?: string;
  title: string;
  investigationType: string;
  status: string;
  incidentDate: string;
  rootCause?: string;
  contributingFactors?: string;
  recommendations?: string;
};

type InvRow = { id: number; aircraftId?: number | null; aircraftRegistration?: string | null; investigatorName?: string | null; title: string; investigationType: string; status: string; incidentDate: string; rootCause?: string | null; contributingFactors?: string | null; recommendations?: string | null };

export default function Investigations() {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<InvRow | null>(null);
  const [expanded, setExpanded] = useState<number | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<InvRow | null>(null);
  const { data: investigations, isLoading } = useListInvestigations();
  const { data: aircraft } = useListAircraft();
  const createInv = useCreateInvestigation();
  const updateInv = useUpdateInvestigation();
  const deleteInv = useDeleteInvestigation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<InvestigationFormData>({
    defaultValues: { status: "open", investigationType: "Safety", incidentDate: new Date().toISOString().split("T")[0] },
  });

  function openCreate() {
    setEditing(null);
    form.reset({ status: "open", investigationType: "Safety", incidentDate: new Date().toISOString().split("T")[0] });
    setOpen(true);
  }

  function openEdit(inv: InvRow) {
    setEditing(inv);
    form.reset({
      aircraftId: inv.aircraftId ?? undefined,
      investigatorName: inv.investigatorName ?? undefined,
      title: inv.title,
      investigationType: inv.investigationType,
      status: inv.status,
      incidentDate: inv.incidentDate,
      rootCause: inv.rootCause ?? undefined,
      contributingFactors: inv.contributingFactors ?? undefined,
      recommendations: inv.recommendations ?? undefined,
    });
    setOpen(true);
  }

  function onSubmit(data: InvestigationFormData) {
    const payload = { ...data, aircraftId: data.aircraftId ? Number(data.aircraftId) : undefined };
    const invalidate = () => queryClient.invalidateQueries({ queryKey: getListInvestigationsQueryKey() });
    if (editing) {
      updateInv.mutate({ id: editing.id, data: payload }, {
        onSuccess: () => { invalidate(); setOpen(false); toast({ title: "Investigation updated" }); },
        onError: () => toast({ title: "Failed to update investigation", variant: "destructive" }),
      });
    } else {
      createInv.mutate({ data: payload }, {
        onSuccess: () => { invalidate(); setOpen(false); form.reset(); toast({ title: "Investigation opened" }); },
        onError: () => toast({ title: "Failed to open investigation", variant: "destructive" }),
      });
    }
  }

  function handleStatusChange(id: number, status: string) {
    updateInv.mutate({ id, data: { status } }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListInvestigationsQueryKey() }),
    });
  }

  function confirmDelete() {
    if (!deleteTarget) return;
    deleteInv.mutate({ id: deleteTarget.id }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListInvestigationsQueryKey() }); setDeleteTarget(null); toast({ title: "Investigation deleted" }); },
      onError: () => toast({ title: "Failed to delete investigation", variant: "destructive" }),
    });
  }

  return (
    <div className="flex-1 overflow-auto">
      <PageHeader
        title="Investigations"
        subtitle="Accident and incident investigations"
        action={<Button size="sm" onClick={openCreate}><Plus className="w-4 h-4 mr-1" /> Open Investigation</Button>}
      />
      <div className="p-6 space-y-3">
        {isLoading ? (
          <div className="space-y-2">{[...Array(4)].map((_, i) => <div key={i} className="h-20 bg-muted animate-pulse rounded-lg" />)}</div>
        ) : (investigations ?? []).length === 0 ? (
          <p className="text-muted-foreground text-center py-10">No investigations found</p>
        ) : (
          (investigations ?? []).map((inv) => {
            const isExpanded = expanded === inv.id;
            return (
              <div key={inv.id} className="bg-card border border-border rounded-lg overflow-hidden">
                <div className="p-4 flex items-start gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <StatusBadge value={inv.status} />
                      <span className="text-xs text-muted-foreground bg-muted rounded px-1.5 py-0.5">{inv.investigationType}</span>
                      {inv.aircraftRegistration && <span className="font-mono text-xs text-primary">{inv.aircraftRegistration}</span>}
                    </div>
                    <p className="text-sm font-semibold text-foreground">{inv.title}</p>
                    <div className="flex gap-4 mt-1 text-xs text-muted-foreground flex-wrap">
                      <span>Incident: {inv.incidentDate}</span>
                      {inv.investigatorName && <span>Investigator: {inv.investigatorName}</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <Select value={inv.status} onValueChange={(v) => handleStatusChange(inv.id, v)}>
                      <SelectTrigger className="w-32 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="open">Open</SelectItem>
                        <SelectItem value="in-progress">In Progress</SelectItem>
                        <SelectItem value="closed">Closed</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-foreground" onClick={() => openEdit(inv)}><Pencil className="w-3.5 h-3.5" /></Button>
                    <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-destructive" onClick={() => setDeleteTarget(inv)}><Trash2 className="w-3.5 h-3.5" /></Button>
                    <Button size="icon" variant="ghost" className="w-7 h-7" onClick={() => setExpanded(isExpanded ? null : inv.id)}>
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>
                {isExpanded && (
                  <div className="border-t border-border px-4 py-3 space-y-2 bg-muted/20">
                    {inv.rootCause && <div><p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Root Cause</p><p className="text-sm text-foreground mt-0.5">{inv.rootCause}</p></div>}
                    {inv.contributingFactors && <div><p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Contributing Factors</p><p className="text-sm text-foreground mt-0.5">{inv.contributingFactors}</p></div>}
                    {inv.recommendations && <div><p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Recommendations</p><p className="text-sm text-blue-700 mt-0.5">{inv.recommendations}</p></div>}
                    {!inv.rootCause && !inv.contributingFactors && !inv.recommendations && <p className="text-sm text-muted-foreground">Investigation in progress — no findings yet.</p>}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editing ? "Edit Investigation" : "Open Investigation"}</DialogTitle></DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label>Title *</Label>
                <Input {...form.register("title", { required: true })} />
              </div>
              <div>
                <Label>Type *</Label>
                <Select value={form.watch("investigationType")} onValueChange={(v) => form.setValue("investigationType", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Safety">Safety</SelectItem>
                    <SelectItem value="Technical">Technical</SelectItem>
                    <SelectItem value="Human Factors">Human Factors</SelectItem>
                    <SelectItem value="Operational">Operational</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Status</Label>
                <Select value={form.watch("status")} onValueChange={(v) => form.setValue("status", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Incident Date *</Label>
                <Input type="date" {...form.register("incidentDate", { required: true })} />
              </div>
              <div>
                <Label>Aircraft</Label>
                <Select value={form.watch("aircraftId") ? String(form.watch("aircraftId")) : "none"} onValueChange={(v) => form.setValue("aircraftId", v === "none" ? undefined : Number(v))}>
                  <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {(aircraft ?? []).map((a) => <SelectItem key={a.id} value={String(a.id)}>{a.registrationNo}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Investigator</Label>
                <Input {...form.register("investigatorName")} />
              </div>
            </div>
            <div><Label>Root Cause</Label><Textarea {...form.register("rootCause")} rows={2} /></div>
            <div><Label>Contributing Factors</Label><Textarea {...form.register("contributingFactors")} rows={2} /></div>
            <div><Label>Recommendations</Label><Textarea {...form.register("recommendations")} rows={2} /></div>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={createInv.isPending || updateInv.isPending}>
                {createInv.isPending || updateInv.isPending ? "Saving..." : editing ? "Save Changes" : "Open Investigation"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Delete Investigation</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Delete "<span className="font-semibold text-foreground">{deleteTarget?.title}</span>"? This cannot be undone.</p>
          <div className="flex justify-end gap-2 mt-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleteInv.isPending}>{deleteInv.isPending ? "Deleting..." : "Delete"}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
