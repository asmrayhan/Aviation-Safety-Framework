import { useState } from "react";
import { useListUsers, useCreateUser, useUpdateUser, useDeleteUser, getListUsersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/layout";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { Plus, UserCheck, UserX, Pencil, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type UserFormData = {
  name: string;
  email: string;
  role: string;
  organization?: string;
  isActive: boolean;
};

type UserRow = { id: number; name: string; email: string; role: string; organization?: string | null; isActive?: boolean | null };

const ROLES = [
  { value: "maintenance_engineer", label: "Maintenance Engineer" },
  { value: "operator", label: "Operator / Flight Crew" },
  { value: "safety_official", label: "Safety Official" },
  { value: "accident_investigator", label: "Accident Investigator" },
];

export default function Users() {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<UserRow | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<UserRow | null>(null);
  const { data: users, isLoading } = useListUsers();
  const createUser = useCreateUser();
  const updateUser = useUpdateUser();
  const deleteUser = useDeleteUser();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<UserFormData>({ defaultValues: { role: "operator", isActive: true } });

  function openCreate() {
    setEditing(null);
    form.reset({ role: "operator", isActive: true });
    setOpen(true);
  }

  function openEdit(u: UserRow) {
    setEditing(u);
    form.reset({
      name: u.name,
      email: u.email,
      role: u.role,
      organization: u.organization ?? undefined,
      isActive: u.isActive ?? true,
    });
    setOpen(true);
  }

  function onSubmit(data: UserFormData) {
    const invalidate = () => queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
    if (editing) {
      updateUser.mutate({ id: editing.id, data }, {
        onSuccess: () => { invalidate(); setOpen(false); toast({ title: "User updated" }); },
        onError: () => toast({ title: "Failed to update user", variant: "destructive" }),
      });
    } else {
      createUser.mutate({ data }, {
        onSuccess: () => { invalidate(); setOpen(false); form.reset(); toast({ title: "User created" }); },
        onError: () => toast({ title: "Failed to create user", variant: "destructive" }),
      });
    }
  }

  function toggleActive(id: number, current: boolean | null | undefined) {
    updateUser.mutate({ id, data: { isActive: !current } }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() }),
    });
  }

  function confirmDelete() {
    if (!deleteTarget) return;
    deleteUser.mutate({ id: deleteTarget.id }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() }); setDeleteTarget(null); toast({ title: "User deleted" }); },
      onError: () => toast({ title: "Failed to delete user", variant: "destructive" }),
    });
  }

  return (
    <div className="flex-1 overflow-auto">
      <PageHeader
        title="Users"
        subtitle="System users and role management"
        action={<Button size="sm" onClick={openCreate}><Plus className="w-4 h-4 mr-1" /> Add User</Button>}
      />
      <div className="p-6">
        {isLoading ? (
          <div className="space-y-2">{[...Array(5)].map((_, i) => <div key={i} className="h-14 bg-muted animate-pulse rounded" />)}</div>
        ) : (
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  <th className="text-left px-4 py-2.5 font-medium text-muted-foreground">Name</th>
                  <th className="text-left px-4 py-2.5 font-medium text-muted-foreground">Email</th>
                  <th className="text-left px-4 py-2.5 font-medium text-muted-foreground">Role</th>
                  <th className="text-left px-4 py-2.5 font-medium text-muted-foreground">Organization</th>
                  <th className="text-left px-4 py-2.5 font-medium text-muted-foreground">Status</th>
                  <th className="px-4 py-2.5"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {(users ?? []).length === 0 && <tr><td colSpan={6} className="text-center py-10 text-muted-foreground">No users found</td></tr>}
                {(users ?? []).map((u) => (
                  <tr key={u.id} className="hover:bg-muted/20">
                    <td className="px-4 py-3 font-medium text-foreground">{u.name}</td>
                    <td className="px-4 py-3 text-muted-foreground text-xs">{u.email}</td>
                    <td className="px-4 py-3"><StatusBadge value={u.role} /></td>
                    <td className="px-4 py-3 text-muted-foreground text-xs">{u.organization ?? "—"}</td>
                    <td className="px-4 py-3">
                      <button onClick={() => toggleActive(u.id, u.isActive)} className={`inline-flex items-center gap-1 text-xs hover:opacity-80 transition-opacity ${u.isActive ? "text-green-600" : "text-muted-foreground"}`}>
                        {u.isActive ? <UserCheck className="w-3.5 h-3.5" /> : <UserX className="w-3.5 h-3.5" />}
                        {u.isActive ? "Active" : "Inactive"}
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 justify-end">
                        <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-foreground" onClick={() => openEdit(u)}><Pencil className="w-3.5 h-3.5" /></Button>
                        <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-destructive" onClick={() => setDeleteTarget(u)}><Trash2 className="w-3.5 h-3.5" /></Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Edit User" : "Add User"}</DialogTitle></DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label>Full Name *</Label>
                <Input {...form.register("name", { required: true })} />
              </div>
              <div className="col-span-2">
                <Label>Email *</Label>
                <Input type="email" {...form.register("email", { required: true })} />
              </div>
              <div>
                <Label>Role *</Label>
                <Select value={form.watch("role")} onValueChange={(v) => form.setValue("role", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{ROLES.map((r) => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Organization</Label>
                <Input {...form.register("organization")} />
              </div>
              <div className="col-span-2">
                <Label>Status</Label>
                <Select value={form.watch("isActive") ? "active" : "inactive"} onValueChange={(v) => form.setValue("isActive", v === "active")}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={createUser.isPending || updateUser.isPending}>
                {createUser.isPending || updateUser.isPending ? "Saving..." : editing ? "Save Changes" : "Create User"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Delete User</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Delete <span className="font-semibold text-foreground">{deleteTarget?.name}</span> from the system? This cannot be undone.</p>
          <div className="flex justify-end gap-2 mt-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleteUser.isPending}>{deleteUser.isPending ? "Deleting..." : "Delete"}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
