import { useState } from "react";
import { useListAlerts, useMarkAlertRead, useDeleteAlert, getListAlertsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/layout";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CheckCheck, BellOff, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

type AlertRow = { id: number; alertType: string; message: string; severity: string; isRead: boolean; aircraftRegistration?: string | null; createdAt: string };

export default function Alerts() {
  const [showAll, setShowAll] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<AlertRow | null>(null);
  const { data: alerts, isLoading } = useListAlerts(showAll ? {} as never : { query: { params: { isRead: false } } } as never);
  const markRead = useMarkAlertRead();
  const deleteAlert = useDeleteAlert();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const invalidate = () => queryClient.invalidateQueries({ queryKey: getListAlertsQueryKey() });

  function handleMarkRead(id: number) {
    markRead.mutate({ id }, { onSuccess: invalidate });
  }

  function confirmDelete() {
    if (!deleteTarget) return;
    deleteAlert.mutate({ id: deleteTarget.id }, {
      onSuccess: () => { invalidate(); setDeleteTarget(null); toast({ title: "Alert dismissed" }); },
      onError: () => toast({ title: "Failed to dismiss alert", variant: "destructive" }),
    });
  }

  const unread = (alerts ?? []).filter((a) => !a.isRead).length;

  return (
    <div className="flex-1 overflow-auto">
      <PageHeader
        title="Safety Alerts"
        subtitle={`${unread} unread alert${unread !== 1 ? "s" : ""}`}
        action={
          <Button size="sm" variant={showAll ? "default" : "outline"} onClick={() => setShowAll(!showAll)}>
            {showAll ? "Show Unread" : "Show All"}
          </Button>
        }
      />
      <div className="p-6 space-y-3">
        {isLoading ? (
          <div className="space-y-2">{[...Array(4)].map((_, i) => <div key={i} className="h-20 bg-muted animate-pulse rounded-lg" />)}</div>
        ) : (alerts ?? []).length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <BellOff className="w-8 h-8 mb-3 opacity-40" />
            <p>No alerts{showAll ? "" : " — you're all caught up"}</p>
          </div>
        ) : (
          (alerts ?? []).map((alert) => (
            <div
              key={alert.id}
              className={cn(
                "bg-card border rounded-lg p-4 flex items-start gap-4 transition-opacity",
                alert.isRead ? "border-border opacity-60" : "border-border shadow-sm"
              )}
            >
              <div className="mt-0.5"><StatusBadge value={alert.severity} /></div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-semibold text-foreground">{alert.alertType}</p>
                  {alert.aircraftRegistration && <span className="font-mono text-xs text-primary">{alert.aircraftRegistration}</span>}
                  {!alert.isRead && <span className="w-2 h-2 rounded-full bg-primary flex-shrink-0" />}
                </div>
                <p className="text-sm text-foreground mt-0.5">{alert.message}</p>
                <p className="text-xs text-muted-foreground mt-1">{new Date(alert.createdAt).toLocaleString()}</p>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                {!alert.isRead && (
                  <Button size="sm" variant="outline" className="text-xs" onClick={() => handleMarkRead(alert.id)} disabled={markRead.isPending}>
                    <CheckCheck className="w-3.5 h-3.5 mr-1" />Mark Read
                  </Button>
                )}
                <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-destructive" onClick={() => setDeleteTarget(alert as AlertRow)}>
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
          ))
        )}
      </div>

      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Dismiss Alert</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Permanently dismiss the "<span className="font-semibold text-foreground">{deleteTarget?.alertType}</span>" alert? This cannot be undone.</p>
          <div className="flex justify-end gap-2 mt-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleteAlert.isPending}>{deleteAlert.isPending ? "Dismissing..." : "Dismiss"}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
