import { useState } from "react";
import { useListLifeComponents, useCreateLifeComponent, useUpdateLifeComponent, useDeleteLifeComponent, getListLifeComponentsQueryKey, useListAircraft } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type ComponentFormData = {
  aircraftId: number;
  componentName: string;
  partNumber?: string;
  tbo: number;
  tsn: number;
  installDate?: string;
  notes?: string;
};

type ComponentRow = { id: number; aircraftId: number; aircraftRegistration?: string | null; componentName: string; partNumber?: string | null; tbo: number; tsn: number; remainingLife?: number | null; installDate?: string | null; notes?: string | null };

export default function LifeComponents() {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<ComponentRow | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<ComponentRow | null>(null);
  const { data: components, isLoading } = useListLifeComponents();
  const { data: aircraft } = useListAircraft();
  const createComponent = useCreateLifeComponent();
  const updateComponent = useUpdateLifeComponent();
  const deleteComponent = useDeleteLifeComponent();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<ComponentFormData>({ defaultValues: { tbo: 0, tsn: 0 } });

  function openCreate() {
    setEditing(null);
    form.reset({ tbo: 0, tsn: 0 });
    setOpen(true);
  }

  function openEdit(c: ComponentRow) {
    setEditing(c);
    form.reset({
      aircraftId: c.aircraftId,
      componentName: c.componentName,
      partNumber: c.partNumber ?? undefined,
      tbo: c.tbo,
      tsn: c.tsn,
      installDate: c.installDate ?? undefined,
      notes: c.notes ?? undefined,
    });
    setOpen(true);
  }

  function onSubmit(data: ComponentFormData) {
    const payload = { ...data, aircraftId: Number(data.aircraftId), tbo: Number(data.tbo), tsn: Number(data.tsn) };
    const invalidate = () => queryClient.invalidateQueries({ queryKey: getListLifeComponentsQueryKey() });
    if (editing) {
      updateComponent.mutate({ id: editing.id, data: payload }, {
        onSuccess: () => { invalidate(); setOpen(false); toast({ title: "Component updated" }); },
        onError: () => toast({ title: "Failed to update component", variant: "destructive" }),
      });
    } else {
      createComponent.mutate({ data: payload }, {
        onSuccess: () => { invalidate(); setOpen(false); form.reset(); toast({ title: "Component added" }); },
        onError: () => toast({ title: "Failed to add component", variant: "destructive" }),
      });
    }
  }

  function confirmDelete() {
    if (!deleteTarget) return;
    deleteComponent.mutate({ id: deleteTarget.id }, {
      onSuccess: () => { queryClient.invalidateQueries({ queryKey: getListLifeComponentsQueryKey() }); setDeleteTarget(null); toast({ title: "Component removed" }); },
      onError: () => toast({ title: "Failed to delete component", variant: "destructive" }),
    });
  }

  return (
    <div className="flex-1 overflow-auto">
      <PageHeader
        title="Life-Limited Components"
        subtitle="TBO and TSN tracking for critical aircraft components"
        action={<Button size="sm" onClick={openCreate}><Plus className="w-4 h-4 mr-1" /> Add Component</Button>}
      />
      <div className="p-6">
        {isLoading ? (
          <div className="space-y-2">{[...Array(5)].map((_, i) => <div key={i} className="h-20 bg-muted animate-pulse rounded-lg" />)}</div>
        ) : (
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  <th className="text-left px-4 py-2.5 font-medium text-muted-foreground">Aircraft</th>
                  <th className="text-left px-4 py-2.5 font-medium text-muted-foreground">Component</th>
                  <th className="text-left px-4 py-2.5 font-medium text-muted-foreground">Part No</th>
                  <th className="text-right px-4 py-2.5 font-medium text-muted-foreground">TSN</th>
                  <th className="text-right px-4 py-2.5 font-medium text-muted-foreground">TBO</th>
                  <th className="text-right px-4 py-2.5 font-medium text-muted-foreground">Remaining</th>
                  <th className="px-4 py-2.5 font-medium text-muted-foreground">Life Used</th>
                  <th className="px-4 py-2.5"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {(components ?? []).length === 0 && <tr><td colSpan={8} className="text-center py-10 text-muted-foreground">No life components found</td></tr>}
                {(components ?? []).map((c) => {
                  const pct = Math.min(100, (c.tsn / c.tbo) * 100);
                  const isOver = c.tsn > c.tbo;
                  const isNear = pct >= 90;
                  return (
                    <tr key={c.id} className={cn("hover:bg-muted/20", isOver && "bg-red-50 dark:bg-red-950/20")}>
                      <td className="px-4 py-3 font-mono text-primary font-semibold">{c.aircraftRegistration ?? c.aircraftId}</td>
                      <td className="px-4 py-3">
                        <p className="font-medium text-foreground">{c.componentName}</p>
                        {c.installDate && <p className="text-xs text-muted-foreground">Installed: {c.installDate}</p>}
                      </td>
                      <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{c.partNumber ?? "—"}</td>
                      <td className="px-4 py-3 text-right font-mono">{c.tsn.toFixed(0)}</td>
                      <td className="px-4 py-3 text-right font-mono">{c.tbo.toFixed(0)}</td>
                      <td className={cn("px-4 py-3 text-right font-mono font-semibold", isOver ? "text-destructive" : isNear ? "text-orange-500" : "text-foreground")}>
                        {isOver ? "EXCEEDED" : (c.remainingLife ?? 0).toFixed(0)}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden w-24">
                            <div className={cn("h-full rounded-full", isOver ? "bg-destructive" : isNear ? "bg-orange-500" : "bg-primary")} style={{ width: `${pct}%` }} />
                          </div>
                          <span className={cn("text-xs", isOver ? "text-destructive font-bold" : "text-muted-foreground")}>{pct.toFixed(0)}%</span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1 justify-end">
                          <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-foreground" onClick={() => openEdit(c)}><Pencil className="w-3.5 h-3.5" /></Button>
                          <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-destructive" onClick={() => setDeleteTarget(c)}><Trash2 className="w-3.5 h-3.5" /></Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Edit Life Component" : "Add Life-Limited Component"}</DialogTitle></DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label>Aircraft *</Label>
                <Select value={form.watch("aircraftId") ? String(form.watch("aircraftId")) : ""} onValueChange={(v) => form.setValue("aircraftId", Number(v))}>
                  <SelectTrigger><SelectValue placeholder="Select aircraft" /></SelectTrigger>
                  <SelectContent>{(aircraft ?? []).map((a) => <SelectItem key={a.id} value={String(a.id)}>{a.registrationNo}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="col-span-2">
                <Label>Component Name *</Label>
                <Input {...form.register("componentName", { required: true })} placeholder="CFM56-7B Engine #1" />
              </div>
              <div>
                <Label>Part Number</Label>
                <Input {...form.register("partNumber")} />
              </div>
              <div>
                <Label>Install Date</Label>
                <Input type="date" {...form.register("installDate")} />
              </div>
              <div>
                <Label>TBO (hrs) *</Label>
                <Input type="number" step="0.1" {...form.register("tbo", { valueAsNumber: true })} />
              </div>
              <div>
                <Label>TSN (hrs) *</Label>
                <Input type="number" step="0.1" {...form.register("tsn", { valueAsNumber: true })} />
              </div>
              <div className="col-span-2">
                <Label>Notes</Label>
                <Input {...form.register("notes")} />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={createComponent.isPending || updateComponent.isPending}>
                {createComponent.isPending || updateComponent.isPending ? "Saving..." : editing ? "Save Changes" : "Save"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Remove Component</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Remove <span className="font-semibold text-foreground">{deleteTarget?.componentName}</span> from <span className="font-mono text-foreground">{deleteTarget?.aircraftRegistration}</span>? This cannot be undone.</p>
          <div className="flex justify-end gap-2 mt-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleteComponent.isPending}>{deleteComponent.isPending ? "Removing..." : "Remove"}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
