import { useState, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { Trash2, Settings, CheckSquare, Square, RefreshCw, ScrollText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

type LogEntry = {
  id: number;
  action: string;
  entity: string;
  entityId: number | null;
  entityLabel: string | null;
  details: unknown;
  createdAt: string;
};

type LogsResponse = {
  data: LogEntry[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
};

type Settings = { autoDeleteDays: number | null };

const LIMIT = 50;

const ACTION_COLOR: Record<string, string> = {
  create: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  update: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  delete: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

const ENTITY_LABELS: Record<string, string> = {
  aircraft: "Aircraft",
  "flight-records": "Flight Records",
  maintenance: "Maintenance",
  "life-components": "Life Components",
  "safety-reports": "Safety Reports",
  alerts: "Alerts",
  investigations: "Investigations",
  users: "Users",
};

async function apiFetch(path: string, init?: RequestInit) {
  const res = await fetch(`${BASE}/api${path}`, {
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  if (!res.ok && res.status !== 204) throw new Error(`API error ${res.status}`);
  if (res.status === 204) return null;
  return res.json();
}

export default function AuditLogs() {
  const [page, setPage] = useState(1);
  const [entityFilter, setEntityFilter] = useState("all");
  const [actionFilter, setActionFilter] = useState("all");
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [autoDeleteDays, setAutoDeleteDays] = useState<string>("disabled");
  const [clearAllOpen, setClearAllOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const logsKey = ["audit-logs", page, entityFilter, actionFilter];

  const { data, isLoading, isFetching } = useQuery<LogsResponse>({
    queryKey: logsKey,
    queryFn: () => {
      const params = new URLSearchParams({ page: String(page), limit: String(LIMIT) });
      if (entityFilter !== "all") params.set("entity", entityFilter);
      if (actionFilter !== "all") params.set("action", actionFilter);
      return apiFetch(`/audit-logs?${params}`);
    },
    placeholderData: (prev) => prev,
  });

  const { data: settings } = useQuery<Settings>({
    queryKey: ["audit-logs-settings"],
    queryFn: () => apiFetch("/audit-logs/settings"),
    staleTime: 30000,
  });

  const deleteSingle = useMutation({
    mutationFn: (id: number) => apiFetch(`/audit-logs/${id}`, { method: "DELETE" }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["audit-logs"] }); toast({ title: "Log entry deleted" }); },
  });

  const deleteBulk = useMutation({
    mutationFn: (ids: number[]) => apiFetch("/audit-logs/bulk", { method: "DELETE", body: JSON.stringify({ ids }) }),
    onSuccess: () => {
      setSelected(new Set());
      queryClient.invalidateQueries({ queryKey: ["audit-logs"] });
      toast({ title: "Selected entries deleted" });
    },
  });

  const deleteAll = useMutation({
    mutationFn: () => apiFetch("/audit-logs/all", { method: "DELETE" }),
    onSuccess: () => {
      setSelected(new Set());
      setClearAllOpen(false);
      queryClient.invalidateQueries({ queryKey: ["audit-logs"] });
      toast({ title: "All log entries cleared" });
    },
  });

  const saveSettings = useMutation({
    mutationFn: (days: number | null) => apiFetch("/audit-logs/settings", { method: "PUT", body: JSON.stringify({ autoDeleteDays: days }) }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["audit-logs-settings"] });
      queryClient.invalidateQueries({ queryKey: ["audit-logs"] });
      setSettingsOpen(false);
      toast({ title: "Auto-delete settings saved" });
    },
  });

  const rows = data?.data ?? [];
  const total = data?.total ?? 0;
  const totalPages = data?.totalPages ?? 1;

  const allSelected = rows.length > 0 && rows.every((r) => selected.has(r.id));

  const toggleAll = useCallback(() => {
    if (allSelected) {
      setSelected((s) => { const n = new Set(s); rows.forEach((r) => n.delete(r.id)); return n; });
    } else {
      setSelected((s) => { const n = new Set(s); rows.forEach((r) => n.add(r.id)); return n; });
    }
  }, [allSelected, rows]);

  const toggleOne = useCallback((id: number) => {
    setSelected((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  }, []);

  function openSettings() {
    setAutoDeleteDays(settings?.autoDeleteDays ? String(settings.autoDeleteDays) : "disabled");
    setSettingsOpen(true);
  }

  function handleSaveSettings() {
    const days = autoDeleteDays === "disabled" ? null : Number(autoDeleteDays);
    saveSettings.mutate(days);
  }

  const activeAutoDelete = settings?.autoDeleteDays;

  return (
    <div className="flex-1 overflow-auto">
      <PageHeader
        title="Activity Log"
        subtitle={`${total.toLocaleString()} total records${activeAutoDelete ? ` · auto-deleting after ${activeAutoDelete} days` : ""}`}
        action={
          <div className="flex items-center gap-2">
            {selected.size > 0 && (
              <Button size="sm" variant="destructive" onClick={() => deleteBulk.mutate([...selected])} disabled={deleteBulk.isPending}>
                <Trash2 className="w-3.5 h-3.5 mr-1" />
                Delete {selected.size} selected
              </Button>
            )}
            <Button size="sm" variant="outline" onClick={() => setClearAllOpen(true)}>Clear All</Button>
            <Button size="sm" variant="outline" onClick={openSettings}><Settings className="w-3.5 h-3.5 mr-1" />Settings</Button>
          </div>
        }
      />

      <div className="p-6 space-y-4">
        {/* Filters */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <Label className="text-xs text-muted-foreground">Entity</Label>
            <Select value={entityFilter} onValueChange={(v) => { setEntityFilter(v); setPage(1); setSelected(new Set()); }}>
              <SelectTrigger className="w-44 text-xs h-8"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Entities</SelectItem>
                {Object.entries(ENTITY_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-2">
            <Label className="text-xs text-muted-foreground">Action</Label>
            <Select value={actionFilter} onValueChange={(v) => { setActionFilter(v); setPage(1); setSelected(new Set()); }}>
              <SelectTrigger className="w-36 text-xs h-8"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Actions</SelectItem>
                <SelectItem value="create">Create</SelectItem>
                <SelectItem value="update">Update</SelectItem>
                <SelectItem value="delete">Delete</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {isFetching && <RefreshCw className="w-3.5 h-3.5 animate-spin text-muted-foreground" />}
        </div>

        {/* Table */}
        {isLoading ? (
          <div className="space-y-1">{[...Array(10)].map((_, i) => <div key={i} className="h-10 bg-muted animate-pulse rounded" />)}</div>
        ) : rows.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <ScrollText className="w-8 h-8 mx-auto mb-3 opacity-30" />
            <p>No activity logged yet. Actions on records will appear here.</p>
          </div>
        ) : (
          <div className="bg-card border border-border rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  <th className="px-3 py-2.5 w-10">
                    <button onClick={toggleAll} className="flex items-center text-muted-foreground hover:text-foreground">
                      {allSelected ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                    </button>
                  </th>
                  <th className="text-left px-3 py-2.5 font-medium text-muted-foreground">Timestamp</th>
                  <th className="text-left px-3 py-2.5 font-medium text-muted-foreground">Action</th>
                  <th className="text-left px-3 py-2.5 font-medium text-muted-foreground">Entity</th>
                  <th className="text-left px-3 py-2.5 font-medium text-muted-foreground">Record</th>
                  <th className="px-3 py-2.5 w-12"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {rows.map((row) => (
                  <tr key={row.id} className={cn("hover:bg-muted/20 transition-colors", selected.has(row.id) && "bg-primary/5")}>
                    <td className="px-3 py-2.5">
                      <button onClick={() => toggleOne(row.id)} className="flex items-center text-muted-foreground hover:text-foreground">
                        {selected.has(row.id) ? <CheckSquare className="w-4 h-4 text-primary" /> : <Square className="w-4 h-4" />}
                      </button>
                    </td>
                    <td className="px-3 py-2.5 text-xs text-muted-foreground font-mono whitespace-nowrap">
                      {new Date(row.createdAt).toLocaleString("en-BD", { dateStyle: "short", timeStyle: "medium" })}
                    </td>
                    <td className="px-3 py-2.5">
                      <span className={cn("text-xs font-semibold px-1.5 py-0.5 rounded capitalize", ACTION_COLOR[row.action] ?? "bg-muted text-muted-foreground")}>
                        {row.action}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-xs text-foreground capitalize">
                      {ENTITY_LABELS[row.entity] ?? row.entity}
                    </td>
                    <td className="px-3 py-2.5 text-sm text-foreground max-w-xs truncate">
                      {row.entityLabel ?? (row.entityId ? `ID ${row.entityId}` : "—")}
                    </td>
                    <td className="px-3 py-2.5">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="w-7 h-7 text-muted-foreground hover:text-destructive"
                        onClick={() => deleteSingle.mutate(row.id)}
                        disabled={deleteSingle.isPending}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">
              Showing {((page - 1) * LIMIT) + 1}–{Math.min(page * LIMIT, total)} of {total.toLocaleString()} entries
            </p>
            <div className="flex items-center gap-1">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(1)} className="text-xs px-2 h-7">«</Button>
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => p - 1)} className="text-xs px-2 h-7">‹ Prev</Button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                const start = Math.max(1, Math.min(page - 2, totalPages - 4));
                const p = start + i;
                return (
                  <Button
                    key={p}
                    size="sm"
                    variant={p === page ? "default" : "outline"}
                    onClick={() => setPage(p)}
                    className="text-xs px-2 h-7 min-w-7"
                  >
                    {p}
                  </Button>
                );
              })}
              <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)} className="text-xs px-2 h-7">Next ›</Button>
              <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage(totalPages)} className="text-xs px-2 h-7">»</Button>
            </div>
          </div>
        )}
      </div>

      {/* Settings dialog */}
      <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Auto-Delete Settings</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">
            Automatically delete log records older than a selected period. This runs every hour and immediately when you save.
          </p>
          <div className="space-y-4 mt-2">
            <div>
              <Label className="mb-1.5 block">Auto-Delete Period</Label>
              <Select value={autoDeleteDays} onValueChange={setAutoDeleteDays}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="disabled">Disabled — keep all records</SelectItem>
                  <SelectItem value="7">After 7 days</SelectItem>
                  <SelectItem value="15">After 15 days</SelectItem>
                  <SelectItem value="30">After 30 days</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {autoDeleteDays !== "disabled" && (
              <div className="bg-orange-50 dark:bg-orange-950/30 border border-orange-200 dark:border-orange-800 rounded p-3 text-sm text-orange-700 dark:text-orange-300">
                Log entries older than <strong>{autoDeleteDays} days</strong> will be deleted automatically.
                When you save, any existing entries already past this threshold will be deleted immediately.
              </div>
            )}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setSettingsOpen(false)}>Cancel</Button>
              <Button onClick={handleSaveSettings} disabled={saveSettings.isPending}>
                {saveSettings.isPending ? "Saving..." : "Save & Apply"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Clear all confirmation */}
      <Dialog open={clearAllOpen} onOpenChange={setClearAllOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Clear All Logs</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">
            This will permanently delete all <strong>{total.toLocaleString()}</strong> log entries. This cannot be undone.
          </p>
          <div className="flex justify-end gap-2 mt-2">
            <Button variant="outline" onClick={() => setClearAllOpen(false)}>Cancel</Button>
            <Button variant="destructive" onClick={() => deleteAll.mutate()} disabled={deleteAll.isPending}>
              {deleteAll.isPending ? "Clearing..." : "Clear All"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
