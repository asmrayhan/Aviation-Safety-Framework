import { useState } from "react";
import {
  useListSafetyReports, useCreateSafetyReport, useUpdateSafetyReport,
  useDeleteSafetyReport, getListSafetyReportsQueryKey, useListAircraft,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { PageHeader } from "@/components/layout";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useForm, Controller } from "react-hook-form";
import { Plus, Pencil, Trash2, ShieldAlert, ChevronRight, ArrowRight, CheckCircle, RotateCcw, UserCheck, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type ReportType = "CSR" | "VSR" | "MSR";

type ReportFormData = {
  reportType: ReportType;
  workflowStatus?: string;
  aircraftId?: number;
  reporterName?: string;
  reporterContact?: string;
  reporterEmployeeId?: string;
  reporterDepartment?: string;
  reporterRole?: string;
  category: string;
  severity: string;
  description: string;
  location?: string;
  incidentDate: string;
  status?: string;
  occurrenceType?: string;
  flightPhase?: string;
  injuries?: string;
  damage?: string;
  hazardType?: string;
  riskLevel?: string;
  contributingFactors?: string;
  immediateActions?: string;
  fsrRecommendation?: string;
  dfsrRecommendation?: string;
  correctiveAction?: string;
};

type ReportRow = ReportFormData & {
  id: number;
  aircraftRegistration?: string | null;
  createdAt?: string;
};

const REPORT_TYPE_LABELS: Record<ReportType, string> = {
  CSR: "Confidential Safety Report",
  VSR: "Voluntary Safety Report",
  MSR: "Mandatory Safety Report",
};

const REPORT_TYPE_DESC: Record<ReportType, string> = {
  CSR: "Anonymous / confidential — identity protected under CAAB NASP",
  VSR: "Voluntary report of hazards, unsafe acts or near-misses",
  MSR: "Mandatory occurrence report required by CAR/ICAO Annex 13",
};

const REPORT_TYPE_COLORS: Record<ReportType, string> = {
  CSR: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  VSR: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  MSR: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

const WORKFLOW_LABELS: Record<string, string> = {
  submitted: "Submitted",
  fsr_review: "FSR Review",
  dfsr_review: "DFSR Review",
  reporter_action: "Reporter Action Required",
  resolved: "Resolved",
};

const WORKFLOW_COLORS: Record<string, string> = {
  submitted: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",
  fsr_review: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
  dfsr_review: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300",
  reporter_action: "bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-300",
  resolved: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
};

const CSR_CATEGORIES = ["Airworthiness", "ATC / Air Traffic Management", "Ground Operations", "Wildlife / Bird Strike", "Fuel", "Weather", "Human Factors", "Cabin Safety", "Runway Incursion", "Other"];
const VSR_CATEGORIES = ["Near Miss", "Unsafe Act", "Unsafe Condition", "Hazard", "Ground Handling", "Maintenance", "Air Traffic", "Fatigue / Workload", "Communication Failure", "Other"];
const MSR_CATEGORIES = ["Aircraft Accident", "Serious Incident", "Incident", "Technical Failure", "Bird Strike", "Runway Excursion", "CFIT Risk", "Loss of Separation", "Ground Collision", "Other"];
const OCCURRENCE_TYPES = ["Accident", "Serious Incident", "Incident", "Runway Excursion", "Bird Strike", "Ground Damage", "ATC Occurrence", "Other"];
const FLIGHT_PHASES = ["Pre-flight / Ground", "Taxi", "Takeoff", "Initial Climb", "Cruise", "Descent", "Approach", "Landing", "Post-flight / Ground", "Parking"];
const HAZARD_TYPES = ["Physical Hazard", "Human Error", "Organisational Factor", "Environmental Condition", "Technical Defect", "Procedural Gap", "Communication Failure", "Other"];
const RISK_LEVELS = ["High (H)", "Medium (M)", "Low (L)"];
const REPORTER_ROLES = ["Pilot (Captain)", "Pilot (First Officer)", "Aircraft Maintenance Engineer", "Air Traffic Controller", "Flight Dispatcher", "Cabin Crew", "Ground Handling Staff", "Safety Officer", "Other"];

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-3">
      <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground border-b border-border pb-1.5">{title}</h4>
      {children}
    </div>
  );
}

function FieldRow({ children }: { children: React.ReactNode }) {
  return <div className="grid grid-cols-2 gap-3">{children}</div>;
}

function WorkflowBadge({ status }: { status: string }) {
  return (
    <span className={cn("text-xs font-semibold px-2 py-0.5 rounded-full", WORKFLOW_COLORS[status] ?? "bg-muted text-muted-foreground")}>
      {WORKFLOW_LABELS[status] ?? status}
    </span>
  );
}

function TypeBadge({ type }: { type: string }) {
  return (
    <span className={cn("text-xs font-bold px-2 py-0.5 rounded", REPORT_TYPE_COLORS[type as ReportType] ?? "bg-muted text-muted-foreground")}>
      {type}
    </span>
  );
}

export default function SafetyReports() {
  const [typePickerOpen, setTypePickerOpen] = useState(false);
  const [open, setOpen] = useState(false);
  const [selectedType, setSelectedType] = useState<ReportType>("MSR");
  const [editing, setEditing] = useState<ReportRow | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<ReportRow | null>(null);
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [workflowFilter, setWorkflowFilter] = useState<string>("all");

  const { data: reports, isLoading } = useListSafetyReports();
  const { data: aircraft } = useListAircraft();
  const createReport = useCreateSafetyReport();
  const updateReport = useUpdateSafetyReport();
  const deleteReport = useDeleteSafetyReport();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<ReportFormData>({
    defaultValues: { reportType: "MSR", severity: "low", status: "open", workflowStatus: "submitted", incidentDate: new Date().toISOString().split("T")[0] },
  });
  const watchedType = form.watch("reportType");
  const watchedWorkflow = form.watch("workflowStatus");

  const filtered = (reports ?? []).filter((r) => {
    const rt = r as ReportRow;
    if (typeFilter !== "all" && rt.reportType !== typeFilter) return false;
    if (workflowFilter !== "all" && rt.workflowStatus !== workflowFilter) return false;
    return true;
  });

  function openCreate(type: ReportType) {
    setTypePickerOpen(false);
    setSelectedType(type);
    setEditing(null);
    form.reset({
      reportType: type,
      severity: "low",
      status: "open",
      workflowStatus: "submitted",
      incidentDate: new Date().toISOString().split("T")[0],
    });
    setOpen(true);
  }

  function openEdit(r: ReportRow) {
    setEditing(r);
    setSelectedType(r.reportType as ReportType);
    form.reset({
      reportType: r.reportType,
      workflowStatus: r.workflowStatus,
      aircraftId: r.aircraftId,
      reporterName: r.reporterName ?? undefined,
      reporterContact: r.reporterContact ?? undefined,
      reporterEmployeeId: r.reporterEmployeeId ?? undefined,
      reporterDepartment: r.reporterDepartment ?? undefined,
      reporterRole: r.reporterRole ?? undefined,
      category: r.category,
      severity: r.severity,
      description: r.description,
      location: r.location ?? undefined,
      incidentDate: r.incidentDate,
      status: r.status,
      occurrenceType: r.occurrenceType ?? undefined,
      flightPhase: r.flightPhase ?? undefined,
      injuries: r.injuries ?? undefined,
      damage: r.damage ?? undefined,
      hazardType: r.hazardType ?? undefined,
      riskLevel: r.riskLevel ?? undefined,
      contributingFactors: r.contributingFactors ?? undefined,
      immediateActions: r.immediateActions ?? undefined,
      fsrRecommendation: r.fsrRecommendation ?? undefined,
      dfsrRecommendation: r.dfsrRecommendation ?? undefined,
      correctiveAction: r.correctiveAction ?? undefined,
    });
    setOpen(true);
  }

  const invalidate = () => queryClient.invalidateQueries({ queryKey: getListSafetyReportsQueryKey() });

  function onSubmit(data: ReportFormData) {
    const payload = { ...data, aircraftId: data.aircraftId ? Number(data.aircraftId) : undefined };
    if (editing) {
      updateReport.mutate({ id: editing.id, data: payload }, {
        onSuccess: () => { invalidate(); setOpen(false); toast({ title: "Report updated" }); },
        onError: () => toast({ title: "Failed to update report", variant: "destructive" }),
      });
    } else {
      createReport.mutate({ data: payload }, {
        onSuccess: () => { invalidate(); setOpen(false); form.reset(); toast({ title: "Safety report filed" }); },
        onError: () => toast({ title: "Failed to file report", variant: "destructive" }),
      });
    }
  }

  function workflowAction(id: number, updates: Partial<ReportFormData>, successMsg: string) {
    const currentData = form.getValues();
    const payload = { ...currentData, ...updates, aircraftId: currentData.aircraftId ? Number(currentData.aircraftId) : undefined };
    updateReport.mutate({ id, data: payload }, {
      onSuccess: () => { invalidate(); setOpen(false); toast({ title: successMsg }); },
      onError: () => toast({ title: "Action failed", variant: "destructive" }),
    });
  }

  function confirmDelete() {
    if (!deleteTarget) return;
    deleteReport.mutate({ id: deleteTarget.id }, {
      onSuccess: () => { invalidate(); setDeleteTarget(null); toast({ title: "Report deleted" }); },
      onError: () => toast({ title: "Failed to delete report", variant: "destructive" }),
    });
  }

  const editId = editing?.id;
  const wfStatus = watchedWorkflow ?? "submitted";
  const hasDfsr = !!(form.watch("dfsrRecommendation"));
  const hasCorrectiveAction = !!(form.watch("correctiveAction"));

  const categories = watchedType === "CSR" ? CSR_CATEGORIES : watchedType === "VSR" ? VSR_CATEGORIES : MSR_CATEGORIES;

  return (
    <div className="flex-1 overflow-auto">
      <PageHeader
        title="Safety Reports"
        subtitle="CAAB NASP — Confidential, Voluntary & Mandatory Safety Reporting"
        action={
          <Button size="sm" onClick={() => setTypePickerOpen(true)}>
            <Plus className="w-4 h-4 mr-1" /> File Report
          </Button>
        }
      />

      <div className="p-6 space-y-4">
        {/* Filters */}
        <div className="flex gap-2 flex-wrap items-center">
          <div className="flex gap-1">
            {(["all", "CSR", "VSR", "MSR"] as const).map((t) => (
              <Button key={t} size="sm" variant={typeFilter === t ? "default" : "outline"} onClick={() => setTypeFilter(t)} className="text-xs">
                {t === "all" ? "All Types" : t}
              </Button>
            ))}
          </div>
          <div className="flex gap-1 ml-2">
            {["all", "submitted", "fsr_review", "dfsr_review", "reporter_action", "resolved"].map((w) => (
              <Button key={w} size="sm" variant={workflowFilter === w ? "default" : "outline"} onClick={() => setWorkflowFilter(w)} className="text-xs capitalize">
                {w === "all" ? "All Workflow" : WORKFLOW_LABELS[w]}
              </Button>
            ))}
          </div>
        </div>

        {isLoading ? (
          <div className="space-y-2">{[...Array(4)].map((_, i) => <div key={i} className="h-24 bg-muted animate-pulse rounded-lg" />)}</div>
        ) : (
          <div className="space-y-3">
            {filtered.length === 0 && <p className="text-muted-foreground text-center py-10">No safety reports found</p>}
            {filtered.map((r) => {
              const row = r as ReportRow;
              return (
                <div key={row.id} className="bg-card border border-border rounded-lg p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1.5">
                        <TypeBadge type={row.reportType ?? "MSR"} />
                        <WorkflowBadge status={row.workflowStatus ?? "submitted"} />
                        <StatusBadge value={row.severity} />
                        <span className="text-sm font-semibold text-foreground">{row.category}</span>
                        {row.aircraftRegistration && <span className="font-mono text-xs text-primary">{row.aircraftRegistration}</span>}
                      </div>
                      <p className="text-sm text-foreground line-clamp-2">{row.description}</p>
                      <div className="flex gap-4 mt-1.5 text-xs text-muted-foreground flex-wrap">
                        <span>Date: <span className="text-foreground">{row.incidentDate}</span></span>
                        {row.location && <span>Location: <span className="text-foreground">{row.location}</span></span>}
                        {row.reporterName && <span>Reporter: <span className="text-foreground">{row.reporterName}</span></span>}
                        {!row.reporterName && row.reportType === "CSR" && <span className="italic text-purple-500">Anonymous Reporter</span>}
                        {row.reporterRole && <span>Role: <span className="text-foreground">{row.reporterRole}</span></span>}
                      </div>
                      {/* Workflow summary */}
                      <div className="flex gap-3 mt-2 text-xs">
                        {row.fsrRecommendation && <span className="text-yellow-600 dark:text-yellow-400">✓ FSR Recommendation</span>}
                        {row.dfsrRecommendation && <span className="text-orange-600 dark:text-orange-400">✓ DFSR Recommendation</span>}
                        {row.correctiveAction && <span className="text-blue-600 dark:text-blue-400">✓ Corrective Action Submitted</span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Button size="sm" variant="outline" className="text-xs" onClick={() => openEdit(row)}>
                        <Pencil className="w-3.5 h-3.5 mr-1" />View / Edit
                      </Button>
                      <Button size="icon" variant="ghost" className="w-7 h-7 text-muted-foreground hover:text-destructive" onClick={() => setDeleteTarget(row)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Type Picker */}
      <Dialog open={typePickerOpen} onOpenChange={setTypePickerOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Select Report Type</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground mb-2">Choose the appropriate CAAB reporting form:</p>
          <div className="space-y-2">
            {(["CSR", "VSR", "MSR"] as const).map((type) => (
              <button
                key={type}
                onClick={() => openCreate(type)}
                className="w-full text-left p-4 rounded-lg border border-border hover:border-primary hover:bg-muted/40 transition-all group flex items-start gap-3"
              >
                <span className={cn("text-sm font-bold px-2 py-1 rounded shrink-0", REPORT_TYPE_COLORS[type])}>{type}</span>
                <div>
                  <p className="font-semibold text-sm text-foreground">{REPORT_TYPE_LABELS[type]}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{REPORT_TYPE_DESC[type]}</p>
                </div>
                <ChevronRight className="w-4 h-4 ml-auto text-muted-foreground group-hover:text-primary mt-1 shrink-0" />
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Main Form Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center gap-2">
              <TypeBadge type={watchedType} />
              <DialogTitle>{REPORT_TYPE_LABELS[watchedType] ?? "Safety Report"}</DialogTitle>
            </div>
            {editing && <WorkflowBadge status={wfStatus} />}
          </DialogHeader>

          <Tabs defaultValue="form">
            <TabsList className="mb-4">
              <TabsTrigger value="form"><FileText className="w-3.5 h-3.5 mr-1" />Report Details</TabsTrigger>
              <TabsTrigger value="fsr"><UserCheck className="w-3.5 h-3.5 mr-1" />FSR Review</TabsTrigger>
              <TabsTrigger value="dfsr"><ShieldAlert className="w-3.5 h-3.5 mr-1" />DFSR Review</TabsTrigger>
              <TabsTrigger value="action"><RotateCcw className="w-3.5 h-3.5 mr-1" />Corrective Action</TabsTrigger>
            </TabsList>

            <form onSubmit={form.handleSubmit(onSubmit)}>
              {/* ===== TAB 1: REPORT DETAILS ===== */}
              <TabsContent value="form" className="space-y-5">

                {/* Reporter Info */}
                <Section title="Reporter Information">
                  <FieldRow>
                    <div>
                      <Label className="text-xs">{watchedType === "CSR" ? "Reporter Name (optional — leave blank for anonymous)" : "Reporter Name *"}</Label>
                      <Input {...form.register("reporterName")} placeholder={watchedType === "CSR" ? "Anonymous" : "Full name"} />
                    </div>
                    <div>
                      <Label className="text-xs">Reporter Role / Position</Label>
                      <Controller name="reporterRole" control={form.control} render={({ field }) => (
                        <Select value={field.value ?? ""} onValueChange={field.onChange}>
                          <SelectTrigger><SelectValue placeholder="Select role" /></SelectTrigger>
                          <SelectContent>{REPORTER_ROLES.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                        </Select>
                      )} />
                    </div>
                    {watchedType !== "CSR" && <>
                      <div>
                        <Label className="text-xs">Employee ID</Label>
                        <Input {...form.register("reporterEmployeeId")} placeholder="e.g. CAAB-1234" />
                      </div>
                      <div>
                        <Label className="text-xs">Department / Section</Label>
                        <Input {...form.register("reporterDepartment")} placeholder="e.g. Flight Operations" />
                      </div>
                      <div className="col-span-2">
                        <Label className="text-xs">Contact (Email / Phone) {watchedType === "MSR" ? "*" : ""}</Label>
                        <Input {...form.register("reporterContact")} placeholder="For follow-up communication" />
                      </div>
                    </>}
                  </FieldRow>
                </Section>

                {/* Incident Details */}
                <Section title="Incident / Occurrence Details">
                  <FieldRow>
                    <div>
                      <Label className="text-xs">Category *</Label>
                      <Controller name="category" control={form.control} rules={{ required: true }} render={({ field }) => (
                        <Select value={field.value ?? ""} onValueChange={field.onChange}>
                          <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                          <SelectContent>{categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                        </Select>
                      )} />
                    </div>
                    <div>
                      <Label className="text-xs">Severity *</Label>
                      <Controller name="severity" control={form.control} render={({ field }) => (
                        <Select value={field.value} onValueChange={field.onChange}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Low</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="critical">Critical</SelectItem>
                          </SelectContent>
                        </Select>
                      )} />
                    </div>
                    <div>
                      <Label className="text-xs">Incident Date *</Label>
                      <Input type="date" {...form.register("incidentDate", { required: true })} />
                    </div>
                    <div>
                      <Label className="text-xs">Location</Label>
                      <Input {...form.register("location")} placeholder="Airport / Airspace / Route" />
                    </div>
                    <div>
                      <Label className="text-xs">Aircraft</Label>
                      <Controller name="aircraftId" control={form.control} render={({ field }) => (
                        <Select value={field.value ? String(field.value) : "none"} onValueChange={v => field.onChange(v === "none" ? undefined : Number(v))}>
                          <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">None / Unknown</SelectItem>
                            {(aircraft ?? []).map(a => <SelectItem key={a.id} value={String(a.id)}>{a.registrationNo} — {a.aircraftType}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      )} />
                    </div>
                    {watchedType === "MSR" && <>
                      <div>
                        <Label className="text-xs">Occurrence Type *</Label>
                        <Controller name="occurrenceType" control={form.control} render={({ field }) => (
                          <Select value={field.value ?? ""} onValueChange={field.onChange}>
                            <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                            <SelectContent>{OCCURRENCE_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                          </Select>
                        )} />
                      </div>
                      <div>
                        <Label className="text-xs">Phase of Flight</Label>
                        <Controller name="flightPhase" control={form.control} render={({ field }) => (
                          <Select value={field.value ?? ""} onValueChange={field.onChange}>
                            <SelectTrigger><SelectValue placeholder="Select phase" /></SelectTrigger>
                            <SelectContent>{FLIGHT_PHASES.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                          </Select>
                        )} />
                      </div>
                    </>}
                    {watchedType === "VSR" && <>
                      <div>
                        <Label className="text-xs">Hazard Type</Label>
                        <Controller name="hazardType" control={form.control} render={({ field }) => (
                          <Select value={field.value ?? ""} onValueChange={field.onChange}>
                            <SelectTrigger><SelectValue placeholder="Select hazard type" /></SelectTrigger>
                            <SelectContent>{HAZARD_TYPES.map(h => <SelectItem key={h} value={h}>{h}</SelectItem>)}</SelectContent>
                          </Select>
                        )} />
                      </div>
                      <div>
                        <Label className="text-xs">Reporter's Risk Assessment</Label>
                        <Controller name="riskLevel" control={form.control} render={({ field }) => (
                          <Select value={field.value ?? ""} onValueChange={field.onChange}>
                            <SelectTrigger><SelectValue placeholder="Select risk level" /></SelectTrigger>
                            <SelectContent>{RISK_LEVELS.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                          </Select>
                        )} />
                      </div>
                    </>}
                  </FieldRow>
                </Section>

                {/* Narrative */}
                <Section title="Narrative & Details">
                  <div>
                    <Label className="text-xs">Description — What Happened? *</Label>
                    <Textarea {...form.register("description", { required: true })} rows={4} placeholder="Provide a detailed, factual account of the event..." />
                  </div>
                  {watchedType === "MSR" && <>
                    <FieldRow>
                      <div>
                        <Label className="text-xs">Injuries (persons / nature)</Label>
                        <Textarea {...form.register("injuries")} rows={2} placeholder="Describe any injuries..." />
                      </div>
                      <div>
                        <Label className="text-xs">Aircraft / Property Damage</Label>
                        <Textarea {...form.register("damage")} rows={2} placeholder="Describe any damage..." />
                      </div>
                    </FieldRow>
                  </>}
                  {(watchedType === "VSR" || watchedType === "MSR") && (
                    <div>
                      <Label className="text-xs">Contributing Factors</Label>
                      <Textarea {...form.register("contributingFactors")} rows={2} placeholder="Identify possible contributing or causal factors..." />
                    </div>
                  )}
                  <div>
                    <Label className="text-xs">Immediate Actions Taken</Label>
                    <Textarea {...form.register("immediateActions")} rows={2} placeholder="What actions were taken immediately after the event?" />
                  </div>
                </Section>

                <div className="flex justify-end gap-2 pt-2 border-t border-border">
                  <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                  <Button type="submit" disabled={createReport.isPending || updateReport.isPending}>
                    {createReport.isPending || updateReport.isPending ? "Saving..." : editing ? "Save Report" : "File Report"}
                  </Button>
                </div>
              </TabsContent>

              {/* ===== TAB 2: FSR REVIEW ===== */}
              <TabsContent value="fsr" className="space-y-4">
                <div className="bg-yellow-50 dark:bg-yellow-950/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-3">
                  <p className="text-xs font-semibold text-yellow-800 dark:text-yellow-300 mb-0.5">Flight Safety & Regulation Officer (FSR)</p>
                  <p className="text-xs text-yellow-700 dark:text-yellow-400">
                    Review the report, assess risk, and provide your professional recommendation before forwarding to DFSR.
                    After DFSR review, decide whether to resolve or request corrective action from the reporter.
                  </p>
                </div>

                <div>
                  <Label>FSR Recommendation</Label>
                  <Textarea
                    {...form.register("fsrRecommendation")}
                    rows={6}
                    placeholder="Write your safety recommendation, risk assessment, and proposed corrective / preventive actions..."
                    className={cn(wfStatus === "fsr_review" ? "" : "opacity-60")}
                  />
                </div>

                {/* Current workflow status info */}
                <div className="text-xs text-muted-foreground bg-muted/30 rounded p-3 space-y-1">
                  <p className="font-semibold">Current Workflow Status: <WorkflowBadge status={wfStatus} /></p>
                  {wfStatus === "submitted" && <p>This report has been submitted. Take it for FSR review to begin the review process.</p>}
                  {wfStatus === "fsr_review" && !hasDfsr && !hasCorrectiveAction && <p>Write your recommendation above and forward to DFSR for their assessment.</p>}
                  {wfStatus === "fsr_review" && hasDfsr && !hasCorrectiveAction && <p>DFSR has submitted their recommendation. You can now mark as resolved or request corrective action from the reporter.</p>}
                  {wfStatus === "fsr_review" && hasCorrectiveAction && <p>The reporter has submitted their corrective action. You can now review and mark the report as resolved.</p>}
                  {wfStatus === "dfsr_review" && <p>Awaiting DFSR recommendation. Switch to the DFSR Review tab to enter their recommendation.</p>}
                  {wfStatus === "reporter_action" && <p>Awaiting corrective action from the reporter. Switch to the Corrective Action tab.</p>}
                  {wfStatus === "resolved" && <p className="text-green-600 dark:text-green-400 font-semibold">✓ This report has been resolved.</p>}
                </div>

                {editing && editId && (
                  <div className="flex flex-wrap gap-2 justify-end border-t border-border pt-3">
                    {wfStatus === "submitted" && (
                      <Button type="button" variant="outline" onClick={() => workflowAction(editId, { workflowStatus: "fsr_review", status: "under_review" }, "Report taken for FSR review")}>
                        <ArrowRight className="w-3.5 h-3.5 mr-1" /> Take for FSR Review
                      </Button>
                    )}
                    {wfStatus === "fsr_review" && !hasDfsr && (
                      <Button type="button" onClick={() => workflowAction(editId, { workflowStatus: "dfsr_review" }, "Forwarded to DFSR for review")}>
                        <ArrowRight className="w-3.5 h-3.5 mr-1" /> Save & Forward to DFSR
                      </Button>
                    )}
                    {wfStatus === "fsr_review" && hasDfsr && (
                      <>
                        <Button type="button" variant="outline" onClick={() => workflowAction(editId, { workflowStatus: "reporter_action" }, "Sent to reporter for corrective action")}>
                          <RotateCcw className="w-3.5 h-3.5 mr-1" /> Request Corrective Action from Reporter
                        </Button>
                        <Button type="button" className="bg-green-600 hover:bg-green-700 text-white" onClick={() => workflowAction(editId, { workflowStatus: "resolved", status: "resolved" }, "Safety report marked as Resolved")}>
                          <CheckCircle className="w-3.5 h-3.5 mr-1" /> Mark as Resolved
                        </Button>
                      </>
                    )}
                    {wfStatus === "fsr_review" && hasCorrectiveAction && !hasDfsr && (
                      <Button type="button" className="bg-green-600 hover:bg-green-700 text-white" onClick={() => workflowAction(editId, { workflowStatus: "resolved", status: "resolved" }, "Safety report marked as Resolved")}>
                        <CheckCircle className="w-3.5 h-3.5 mr-1" /> Mark as Resolved
                      </Button>
                    )}
                    <Button type="submit" variant="outline" disabled={updateReport.isPending}>
                      {updateReport.isPending ? "Saving..." : "Save FSR Recommendation"}
                    </Button>
                  </div>
                )}
                {!editing && (
                  <div className="flex justify-end border-t border-border pt-3">
                    <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                  </div>
                )}
              </TabsContent>

              {/* ===== TAB 3: DFSR REVIEW ===== */}
              <TabsContent value="dfsr" className="space-y-4">
                <div className="bg-orange-50 dark:bg-orange-950/20 border border-orange-200 dark:border-orange-800 rounded-lg p-3">
                  <p className="text-xs font-semibold text-orange-800 dark:text-orange-300 mb-0.5">Directorate of Flight Safety & Regulations (DFSR)</p>
                  <p className="text-xs text-orange-700 dark:text-orange-400">
                    Review the FSR's recommendation, add your directorate-level recommendation, and forward back to FSR for final review and closure.
                  </p>
                </div>

                {form.watch("fsrRecommendation") && (
                  <div className="bg-yellow-50 dark:bg-yellow-950/20 border border-yellow-200 dark:border-yellow-800 rounded p-3">
                    <p className="text-xs font-semibold text-yellow-700 dark:text-yellow-400 mb-1">FSR Recommendation (read-only)</p>
                    <p className="text-sm text-foreground whitespace-pre-wrap">{form.watch("fsrRecommendation")}</p>
                  </div>
                )}

                <div>
                  <Label>DFSR Recommendation</Label>
                  <Textarea
                    {...form.register("dfsrRecommendation")}
                    rows={6}
                    placeholder="Provide the directorate-level recommendation, regulatory observations, and any required corrective / enforcement actions..."
                    className={cn(wfStatus === "dfsr_review" ? "" : "opacity-60")}
                  />
                </div>

                {editing && editId && (
                  <div className="flex gap-2 justify-end border-t border-border pt-3">
                    {wfStatus === "dfsr_review" && (
                      <Button type="button" onClick={() => workflowAction(editId, { workflowStatus: "fsr_review" }, "Forwarded back to FSR for final review")}>
                        <ArrowRight className="w-3.5 h-3.5 mr-1" /> Save & Forward to FSR (Final Review)
                      </Button>
                    )}
                    <Button type="submit" variant="outline" disabled={updateReport.isPending}>
                      {updateReport.isPending ? "Saving..." : "Save DFSR Recommendation"}
                    </Button>
                  </div>
                )}
                {!editing && (
                  <div className="flex justify-end border-t border-border pt-3">
                    <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                  </div>
                )}
              </TabsContent>

              {/* ===== TAB 4: CORRECTIVE ACTION ===== */}
              <TabsContent value="action" className="space-y-4">
                <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
                  <p className="text-xs font-semibold text-blue-800 dark:text-blue-300 mb-0.5">Reporter — Corrective Action Response</p>
                  <p className="text-xs text-blue-700 dark:text-blue-400">
                    The FSR has requested corrective action. Describe the steps taken to address the identified safety issue,
                    then submit back to FSR for final review.
                  </p>
                </div>

                {form.watch("fsrRecommendation") && (
                  <div className="bg-yellow-50 dark:bg-yellow-950/20 border border-yellow-200 dark:border-yellow-800 rounded p-3">
                    <p className="text-xs font-semibold text-yellow-700 dark:text-yellow-400 mb-1">FSR Recommendation (for reference)</p>
                    <p className="text-sm text-foreground whitespace-pre-wrap">{form.watch("fsrRecommendation")}</p>
                  </div>
                )}
                {form.watch("dfsrRecommendation") && (
                  <div className="bg-orange-50 dark:bg-orange-950/20 border border-orange-200 dark:border-orange-800 rounded p-3">
                    <p className="text-xs font-semibold text-orange-700 dark:text-orange-400 mb-1">DFSR Recommendation (for reference)</p>
                    <p className="text-sm text-foreground whitespace-pre-wrap">{form.watch("dfsrRecommendation")}</p>
                  </div>
                )}

                <div>
                  <Label>Corrective Action Taken</Label>
                  <Textarea
                    {...form.register("correctiveAction")}
                    rows={6}
                    placeholder="Describe in detail the corrective and preventive actions taken in response to the recommendations..."
                    className={cn(wfStatus === "reporter_action" ? "" : "opacity-60")}
                  />
                </div>

                {editing && editId && (
                  <div className="flex gap-2 justify-end border-t border-border pt-3">
                    {wfStatus === "reporter_action" && (
                      <Button type="button" onClick={() => workflowAction(editId, { workflowStatus: "fsr_review" }, "Corrective action submitted — returned to FSR for final review")}>
                        <ArrowRight className="w-3.5 h-3.5 mr-1" /> Submit Corrective Action to FSR
                      </Button>
                    )}
                    <Button type="submit" variant="outline" disabled={updateReport.isPending}>
                      {updateReport.isPending ? "Saving..." : "Save Draft"}
                    </Button>
                  </div>
                )}
                {!editing && (
                  <div className="flex justify-end border-t border-border pt-3">
                    <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                  </div>
                )}
              </TabsContent>
            </form>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Delete Confirm */}
      <Dialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Delete Safety Report</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">
            Permanently delete the <strong>{deleteTarget?.reportType}</strong> — <strong>{deleteTarget?.category}</strong> report?
            This cannot be undone.
          </p>
          <div className="flex justify-end gap-2 mt-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>Cancel</Button>
            <Button variant="destructive" onClick={confirmDelete} disabled={deleteReport.isPending}>
              {deleteReport.isPending ? "Deleting..." : "Delete"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
