import { useGetAircraftSummary, getGetAircraftSummaryQueryKey } from "@workspace/api-client-react";
import { PageHeader } from "@/components/layout";
import { StatusBadge } from "@/components/status-badge";
import { Link } from "wouter";
import { Plane, Wrench, Cpu, Bell, BookOpen, ArrowLeft } from "lucide-react";

export default function AircraftDetail({ id }: { id: string }) {
  const numId = Number(id);
  const { data: summary, isLoading } = useGetAircraftSummary(numId, {
    query: { enabled: !!numId, queryKey: getGetAircraftSummaryQueryKey(numId) },
  });

  if (isLoading) {
    return (
      <div>
        <PageHeader title="Aircraft Detail" />
        <div className="p-6 space-y-4">
          {[...Array(4)].map((_, i) => <div key={i} className="h-32 bg-muted animate-pulse rounded-lg" />)}
        </div>
      </div>
    );
  }

  if (!summary) {
    return (
      <div>
        <PageHeader title="Aircraft Not Found" />
        <div className="p-6">
          <p className="text-muted-foreground">Aircraft not found.</p>
          <Link href="/aircraft" className="text-primary hover:underline mt-2 inline-flex items-center gap-1"><ArrowLeft className="w-3.5 h-3.5" /> Back to Fleet</Link>
        </div>
      </div>
    );
  }

  const { aircraft, recentFlightRecords, pendingMaintenance, criticalLifeComponents, activeAlerts } = summary;

  return (
    <div className="flex-1 overflow-auto">
      <PageHeader
        title={aircraft.registrationNo}
        subtitle={`${aircraft.manufacturer} ${aircraft.model} — ${aircraft.aircraftType}`}
        action={
          <Link href="/aircraft" className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1">
            <ArrowLeft className="w-4 h-4" /> Fleet
          </Link>
        }
      />
      <div className="p-6 space-y-6">
        {/* Aircraft info */}
        <div className="bg-card border border-border rounded-lg p-4 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p className="text-xs text-muted-foreground">Status</p>
            <div className="mt-1"><StatusBadge value={aircraft.status} /></div>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Year</p>
            <p className="text-sm font-semibold text-foreground mt-1">{aircraft.yearOfManufacture ?? "—"}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Total Flying Hrs</p>
            <p className="text-sm font-mono font-semibold text-foreground mt-1">{aircraft.totalFlyingHrs.toFixed(1)}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Total Engine Hrs</p>
            <p className="text-sm font-mono font-semibold text-foreground mt-1">{aircraft.totalEngineHrs.toFixed(1)}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Total Landings</p>
            <p className="text-sm font-mono font-semibold text-foreground mt-1">{aircraft.totalLandings.toLocaleString()}</p>
          </div>
          {aircraft.notes && (
            <div className="col-span-2 md:col-span-3">
              <p className="text-xs text-muted-foreground">Notes</p>
              <p className="text-sm text-foreground mt-1">{aircraft.notes}</p>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Recent Flights */}
          <SectionCard title="Recent Flight Records" icon={BookOpen} count={recentFlightRecords.length}>
            {recentFlightRecords.length === 0 ? <EmptyState /> : recentFlightRecords.map((f) => (
              <div key={f.id} data-testid={`flight-row-${f.id}`} className="flex items-start justify-between py-2 border-b border-border last:border-0">
                <div>
                  <p className="text-sm font-medium text-foreground">{f.flightDate}</p>
                  <p className="text-xs text-muted-foreground">{f.route ?? "No route"} · {f.pilotName ?? "Unknown pilot"}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-mono text-foreground">{f.dailyFlyingHrs.toFixed(1)} hrs</p>
                  <p className="text-xs text-muted-foreground">{f.dailyLandings} ldg</p>
                </div>
              </div>
            ))}
          </SectionCard>

          {/* Maintenance */}
          <SectionCard title="Maintenance Schedule" icon={Wrench} count={pendingMaintenance.length}>
            {pendingMaintenance.length === 0 ? <EmptyState /> : pendingMaintenance.map((m) => (
              <div key={m.id} data-testid={`maint-row-${m.id}`} className="flex items-start gap-3 py-2 border-b border-border last:border-0">
                <StatusBadge value={m.status} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{m.maintenanceType}</p>
                  <p className="text-xs text-muted-foreground">{m.scheduledDate}</p>
                </div>
              </div>
            ))}
          </SectionCard>

          {/* Life Components */}
          <SectionCard title="Life-Limited Components" icon={Cpu} count={criticalLifeComponents.length}>
            {criticalLifeComponents.length === 0 ? <EmptyState /> : criticalLifeComponents.map((c) => {
              const pct = Math.min(100, (c.tsn / c.tbo) * 100);
              const isNear = pct >= 90;
              return (
                <div key={c.id} data-testid={`component-row-${c.id}`} className="py-2 border-b border-border last:border-0">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm font-medium text-foreground">{c.componentName}</p>
                      <p className="text-xs text-muted-foreground">TSN: {c.tsn.toFixed(0)} / TBO: {c.tbo.toFixed(0)} hrs</p>
                    </div>
                    {isNear && <span className="text-xs font-bold text-destructive">CRITICAL</span>}
                  </div>
                  <div className="mt-1.5 h-1.5 bg-muted rounded-full overflow-hidden">
                    <div className={`h-full rounded-full transition-all ${isNear ? "bg-destructive" : "bg-primary"}`} style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </SectionCard>

          {/* Alerts */}
          <SectionCard title="Active Alerts" icon={Bell} count={activeAlerts.length}>
            {activeAlerts.length === 0 ? <EmptyState text="No active alerts" /> : activeAlerts.map((a) => (
              <div key={a.id} data-testid={`alert-row-${a.id}`} className="flex items-start gap-2 py-2 border-b border-border last:border-0">
                <StatusBadge value={a.severity} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{a.alertType}</p>
                  <p className="text-xs text-muted-foreground line-clamp-1">{a.message}</p>
                </div>
              </div>
            ))}
          </SectionCard>
        </div>
      </div>
    </div>
  );
}

function SectionCard({ title, icon: Icon, count, children }: { title: string; icon: React.ElementType; count: number; children: React.ReactNode }) {
  return (
    <div className="bg-card border border-border rounded-lg">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <h3 className="text-sm font-semibold text-foreground flex items-center gap-2"><Icon className="w-4 h-4 text-primary" />{title}</h3>
        <span className="text-xs text-muted-foreground">{count} items</span>
      </div>
      <div className="px-4 py-1">{children}</div>
    </div>
  );
}

function EmptyState({ text = "No records" }: { text?: string }) {
  return <p className="text-sm text-muted-foreground py-4 text-center">{text}</p>;
}
