import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Aircraft from "@/pages/aircraft";
import AircraftDetail from "@/pages/aircraft-detail";
import FlightRecords from "@/pages/flight-records";
import Maintenance from "@/pages/maintenance";
import LifeComponents from "@/pages/life-components";
import SafetyReports from "@/pages/safety-reports";
import Alerts from "@/pages/alerts";
import Investigations from "@/pages/investigations";
import Users from "@/pages/users";
import AuditLogs from "@/pages/audit-logs";

const queryClient = new QueryClient();

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/aircraft" component={Aircraft} />
        <Route path="/aircraft/:id">
          {(params) => <AircraftDetail id={params.id ?? ""} />}
        </Route>
        <Route path="/flight-records" component={FlightRecords} />
        <Route path="/maintenance" component={Maintenance} />
        <Route path="/life-components" component={LifeComponents} />
        <Route path="/safety-reports" component={SafetyReports} />
        <Route path="/alerts" component={Alerts} />
        <Route path="/investigations" component={Investigations} />
        <Route path="/users" component={Users} />
        <Route path="/audit-logs" component={AuditLogs} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
