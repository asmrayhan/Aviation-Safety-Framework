import { cn } from "@/lib/utils";

type Variant = "critical" | "high" | "medium" | "low" | "active" | "maintenance" | "grounded" | "pending" | "in-progress" | "completed" | "open" | "under_review" | "closed" | "resolved" | "default";

const variantMap: Record<string, string> = {
  critical: "bg-red-100 text-red-800 border-red-200",
  high: "bg-orange-100 text-orange-800 border-orange-200",
  medium: "bg-yellow-100 text-yellow-800 border-yellow-200",
  low: "bg-blue-100 text-blue-800 border-blue-200",
  active: "bg-green-100 text-green-800 border-green-200",
  maintenance: "bg-yellow-100 text-yellow-800 border-yellow-200",
  grounded: "bg-red-100 text-red-800 border-red-200",
  pending: "bg-orange-100 text-orange-800 border-orange-200",
  "in-progress": "bg-blue-100 text-blue-800 border-blue-200",
  completed: "bg-green-100 text-green-800 border-green-200",
  open: "bg-orange-100 text-orange-800 border-orange-200",
  under_review: "bg-purple-100 text-purple-800 border-purple-200",
  closed: "bg-gray-100 text-gray-600 border-gray-200",
  resolved: "bg-green-100 text-green-800 border-green-200",
  default: "bg-gray-100 text-gray-600 border-gray-200",
  maintenance_engineer: "bg-blue-100 text-blue-800 border-blue-200",
  operator: "bg-green-100 text-green-800 border-green-200",
  safety_official: "bg-purple-100 text-purple-800 border-purple-200",
  accident_investigator: "bg-red-100 text-red-800 border-red-200",
};

export function StatusBadge({ value, label }: { value: string; label?: string }) {
  const cls = variantMap[value] ?? variantMap.default;
  const display = label ?? value.replace(/_/g, " ");
  return (
    <span className={cn("inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border capitalize", cls)}>
      {display}
    </span>
  );
}
