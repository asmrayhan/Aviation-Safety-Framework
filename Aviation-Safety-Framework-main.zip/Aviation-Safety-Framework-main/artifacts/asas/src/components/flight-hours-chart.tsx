import { useMemo } from "react";
import { useListFlightRecords } from "@workspace/api-client-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { TrendingUp } from "lucide-react";

const AIRCRAFT_COLORS = [
  "hsl(210 100% 50%)",
  "hsl(150 70% 45%)",
  "hsl(45 100% 50%)",
  "hsl(280 70% 60%)",
  "hsl(0 84% 60%)",
  "hsl(195 80% 50%)",
];

function monthLabel(iso: string) {
  const [year, month] = iso.split("-");
  return new Date(Number(year), Number(month) - 1, 1).toLocaleString("default", {
    month: "short",
    year: "2-digit",
  });
}

function getPast6Months(): string[] {
  const months: string[] = [];
  const now = new Date();
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
  }
  return months;
}

export function FlightHoursChart() {
  const { data: records, isLoading } = useListFlightRecords();

  const { chartData, aircraftList } = useMemo(() => {
    if (!records?.length) return { chartData: [], aircraftList: [] };

    const months = getPast6Months();
    const registrations = [...new Set(records.map((r) => r.aircraftRegistration ?? `AC-${r.aircraftId}`))].sort();

    const buckets: Record<string, Record<string, number>> = {};
    for (const m of months) {
      buckets[m] = {};
      for (const reg of registrations) buckets[m][reg] = 0;
    }

    for (const r of records) {
      const ym = r.flightDate.slice(0, 7);
      if (buckets[ym]) {
        const reg = r.aircraftRegistration ?? `AC-${r.aircraftId}`;
        buckets[ym][reg] = (buckets[ym][reg] ?? 0) + r.dailyFlyingHrs;
      }
    }

    const chartData = months.map((m) => ({
      month: monthLabel(m),
      ...Object.fromEntries(
        registrations.map((reg) => [reg, Number(buckets[m][reg].toFixed(1))])
      ),
    }));

    return { chartData, aircraftList: registrations };
  }, [records]);

  return (
    <div className="bg-card border border-border rounded-lg">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-green-600" />
          Monthly Flight Hours — Last 6 Months
        </h2>
        {!isLoading && (
          <span className="text-xs text-muted-foreground">{aircraftList.length} aircraft</span>
        )}
      </div>

      <div className="p-4">
        {isLoading ? (
          <div className="h-56 bg-muted/40 animate-pulse rounded-lg" />
        ) : chartData.length === 0 ? (
          <div className="h-56 flex items-center justify-center text-muted-foreground text-sm">
            No flight records to display
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={220}>
            <BarChart
              data={chartData}
              margin={{ top: 4, right: 8, left: -16, bottom: 0 }}
              barCategoryGap="28%"
              barGap={2}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="hsl(var(--border))"
                vertical={false}
              />
              <XAxis
                dataKey="month"
                tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                axisLine={false}
                tickLine={false}
                unit="h"
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "6px",
                  fontSize: 12,
                  color: "hsl(var(--foreground))",
                }}
                cursor={{ fill: "hsl(var(--muted))", opacity: 0.4 }}
                formatter={(value: number) => [`${value}h`, undefined]}
              />
              <Legend
                iconType="rect"
                iconSize={8}
                wrapperStyle={{ fontSize: 11, paddingTop: 8 }}
              />
              {aircraftList.map((reg, i) => (
                <Bar
                  key={reg}
                  dataKey={reg}
                  name={reg}
                  fill={AIRCRAFT_COLORS[i % AIRCRAFT_COLORS.length]}
                  radius={[2, 2, 0, 0]}
                />
              ))}
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}
