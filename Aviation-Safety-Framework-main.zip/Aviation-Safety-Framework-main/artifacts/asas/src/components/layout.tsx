import { Link, useLocation } from "wouter";
import {
  LayoutDashboard, Plane, BookOpen, Wrench, Cpu, AlertTriangle, Bell, Search, Users, ChevronRight, Sun, Moon, ScrollText
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useListAlerts } from "@workspace/api-client-react";
import { useTheme } from "@/hooks/use-theme";

const navItems = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/aircraft", label: "Fleet", icon: Plane },
  { href: "/flight-records", label: "Flight Records", icon: BookOpen },
  { href: "/maintenance", label: "Maintenance", icon: Wrench },
  { href: "/life-components", label: "Life Components", icon: Cpu },
  { href: "/safety-reports", label: "Safety Reports", icon: AlertTriangle },
  { href: "/alerts", label: "Alerts", icon: Bell },
  { href: "/investigations", label: "Investigations", icon: Search },
  { href: "/users", label: "Users", icon: Users },
  { href: "/audit-logs", label: "Activity Log", icon: ScrollText },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { data: alerts } = useListAlerts({ query: { params: { isRead: false } } } as never);
  const unreadCount = (alerts as unknown[])?.length ?? 0;
  const { theme, toggle } = useTheme();

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="w-56 flex-shrink-0 bg-sidebar text-sidebar-foreground flex flex-col border-r border-sidebar-border">
        {/* Brand */}
        <div className="px-4 py-4 border-b border-sidebar-border">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded bg-primary flex items-center justify-center flex-shrink-0">
              <Plane className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-xs font-bold text-sidebar-foreground leading-tight">ASAS</p>
              <p className="text-[10px] text-sidebar-foreground/50 leading-tight">Aviation Safety System</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-3 px-2 space-y-0.5">
          {navItems.map(({ href, label, icon: Icon }) => {
            const isActive = href === "/" ? location === "/" : location.startsWith(href);
            const isAlerts = href === "/alerts";
            return (
              <Link
                key={href}
                href={href}
                data-testid={`nav-${label.toLowerCase().replace(/\s+/g, "-")}`}
                className={cn(
                  "flex items-center gap-2.5 px-2.5 py-1.5 rounded text-sm transition-colors relative",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-foreground font-medium"
                    : "text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
                )}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span className="flex-1">{label}</span>
                {isAlerts && unreadCount > 0 && (
                  <span className="bg-destructive text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center font-bold">
                    {unreadCount > 9 ? "9+" : unreadCount}
                  </span>
                )}
                {isActive && <ChevronRight className="w-3 h-3 opacity-50" />}
              </Link>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="px-4 py-3 border-t border-sidebar-border space-y-2">
          <button
            onClick={toggle}
            aria-label="Toggle day/night mode"
            className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded text-sm text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent/50 transition-colors"
          >
            {theme === "dark" ? (
              <>
                <Sun className="w-4 h-4 flex-shrink-0 text-yellow-400" />
                <span>Light Mode</span>
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 flex-shrink-0 text-blue-400" />
                <span>Dark Mode</span>
              </>
            )}
          </button>
          <p className="text-[10px] text-sidebar-foreground/40">Bangladesh CAAB</p>
          <p className="text-[10px] text-sidebar-foreground/30">v1.0.0</p>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {children}
      </main>
    </div>
  );
}

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between px-6 py-4 border-b border-border bg-background">
      <div>
        <h1 className="text-lg font-semibold text-foreground">{title}</h1>
        {subtitle && <p className="text-sm text-muted-foreground mt-0.5">{subtitle}</p>}
      </div>
      {action && <div>{action}</div>}
    </div>
  );
}
