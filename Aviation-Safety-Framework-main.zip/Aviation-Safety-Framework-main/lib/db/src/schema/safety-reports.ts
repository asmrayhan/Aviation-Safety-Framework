import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const safetyReportsTable = pgTable("safety_reports", {
  id: serial("id").primaryKey(),
  // Report type & workflow
  reportType: text("report_type").notNull().default("MSR"), // CSR | VSR | MSR
  workflowStatus: text("workflow_status").notNull().default("submitted"),
  // submitted | fsr_review | dfsr_review | reporter_action | resolved
  // Core
  aircraftId: integer("aircraft_id"),
  reporterName: text("reporter_name"),
  reporterContact: text("reporter_contact"),
  reporterEmployeeId: text("reporter_employee_id"),
  reporterDepartment: text("reporter_department"),
  reporterRole: text("reporter_role"),
  category: text("category").notNull(),
  severity: text("severity").notNull().default("low"),
  description: text("description").notNull(),
  location: text("location"),
  incidentDate: text("incident_date").notNull(),
  status: text("status").notNull().default("open"),
  // Type-specific fields
  occurrenceType: text("occurrence_type"),    // MSR
  flightPhase: text("flight_phase"),          // MSR
  injuries: text("injuries"),                 // MSR
  damage: text("damage"),                     // MSR
  hazardType: text("hazard_type"),            // VSR
  riskLevel: text("risk_level"),              // VSR
  contributingFactors: text("contributing_factors"), // VSR + MSR
  immediateActions: text("immediate_actions"), // CSR + VSR + MSR
  // Workflow fields
  fsrRecommendation: text("fsr_recommendation"),
  dfsrRecommendation: text("dfsr_recommendation"),
  correctiveAction: text("corrective_action"),
  // Legacy (kept for backward compat)
  recommendations: text("recommendations"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertSafetyReportSchema = createInsertSchema(safetyReportsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertSafetyReport = z.infer<typeof insertSafetyReportSchema>;
export type SafetyReport = typeof safetyReportsTable.$inferSelect;
