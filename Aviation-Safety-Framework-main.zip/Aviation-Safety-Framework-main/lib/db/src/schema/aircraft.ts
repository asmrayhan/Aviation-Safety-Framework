import { pgTable, text, serial, timestamp, integer, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const aircraftTable = pgTable("aircraft", {
  id: serial("id").primaryKey(),
  registrationNo: text("registration_no").notNull().unique(),
  aircraftType: text("aircraft_type").notNull(),
  manufacturer: text("manufacturer").notNull(),
  model: text("model").notNull(),
  yearOfManufacture: integer("year_of_manufacture"),
  status: text("status").notNull().default("active"),
  totalFlyingHrs: real("total_flying_hrs").notNull().default(0),
  totalEngineHrs: real("total_engine_hrs").notNull().default(0),
  totalLandings: integer("total_landings").notNull().default(0),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertAircraftSchema = createInsertSchema(aircraftTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertAircraft = z.infer<typeof insertAircraftSchema>;
export type Aircraft = typeof aircraftTable.$inferSelect;
