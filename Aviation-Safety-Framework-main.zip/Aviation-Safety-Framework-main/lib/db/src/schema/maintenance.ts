import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { aircraftTable } from "./aircraft";

export const maintenanceTable = pgTable("maintenance", {
  id: serial("id").primaryKey(),
  aircraftId: integer("aircraft_id").notNull().references(() => aircraftTable.id),
  engineerName: text("engineer_name"),
  maintenanceType: text("maintenance_type").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default("pending"),
  scheduledDate: text("scheduled_date").notNull(),
  completedDate: text("completed_date"),
  nextDueDate: text("next_due_date"),
  findings: text("findings"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertMaintenanceSchema = createInsertSchema(maintenanceTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertMaintenance = z.infer<typeof insertMaintenanceSchema>;
export type Maintenance = typeof maintenanceTable.$inferSelect;
