import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const investigationsTable = pgTable("investigations", {
  id: serial("id").primaryKey(),
  safetyReportId: integer("safety_report_id"),
  aircraftId: integer("aircraft_id"),
  investigatorName: text("investigator_name"),
  title: text("title").notNull(),
  investigationType: text("investigation_type").notNull(),
  status: text("status").notNull().default("open"),
  incidentDate: text("incident_date").notNull(),
  rootCause: text("root_cause"),
  contributingFactors: text("contributing_factors"),
  recommendations: text("recommendations"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertInvestigationSchema = createInsertSchema(investigationsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertInvestigation = z.infer<typeof insertInvestigationSchema>;
export type Investigation = typeof investigationsTable.$inferSelect;
