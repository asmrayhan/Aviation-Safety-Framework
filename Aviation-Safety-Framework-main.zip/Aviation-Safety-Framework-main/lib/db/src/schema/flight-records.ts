import { pgTable, text, serial, timestamp, integer, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { aircraftTable } from "./aircraft";

export const flightRecordsTable = pgTable("flight_records", {
  id: serial("id").primaryKey(),
  aircraftId: integer("aircraft_id").notNull().references(() => aircraftTable.id),
  pilotName: text("pilot_name"),
  flightDate: text("flight_date").notNull(),
  dailyFlyingHrs: real("daily_flying_hrs").notNull().default(0),
  dailyEngineHrs: real("daily_engine_hrs").notNull().default(0),
  dailyLandings: integer("daily_landings").notNull().default(0),
  route: text("route"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertFlightRecordSchema = createInsertSchema(flightRecordsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertFlightRecord = z.infer<typeof insertFlightRecordSchema>;
export type FlightRecord = typeof flightRecordsTable.$inferSelect;
