import { pgTable, text, serial, timestamp, integer, jsonb } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const auditLogsTable = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  action: text("action").notNull(), // create | update | delete
  entity: text("entity").notNull(), // aircraft | maintenance | etc.
  entityId: integer("entity_id"),
  entityLabel: text("entity_label"),
  details: jsonb("details"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const logSettingsTable = pgTable("log_settings", {
  id: serial("id").primaryKey(),
  autoDeleteDays: integer("auto_delete_days"), // null = disabled, 7 | 15 | 30
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export type AuditLog = typeof auditLogsTable.$inferSelect;
export type InsertAuditLog = typeof auditLogsTable.$inferInsert;
export type LogSettings = typeof logSettingsTable.$inferSelect;

export const AuditLogSchema = z.object({
  id: z.number(),
  action: z.string(),
  entity: z.string(),
  entityId: z.number().nullable(),
  entityLabel: z.string().nullable(),
  details: z.unknown().nullable(),
  createdAt: z.string(),
});

export const AuditLogListResponseSchema = z.object({
  data: z.array(AuditLogSchema),
  total: z.number(),
  page: z.number(),
  limit: z.number(),
  totalPages: z.number(),
});

export const LogSettingsSchema = z.object({
  autoDeleteDays: z.number().nullable(),
});
