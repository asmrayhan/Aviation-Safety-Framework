import { pgTable, text, serial, timestamp, integer, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { aircraftTable } from "./aircraft";

export const lifeComponentsTable = pgTable("life_components", {
  id: serial("id").primaryKey(),
  aircraftId: integer("aircraft_id").notNull().references(() => aircraftTable.id),
  componentName: text("component_name").notNull(),
  partNumber: text("part_number"),
  tbo: real("tbo").notNull(),
  tsn: real("tsn").notNull(),
  installDate: text("install_date"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertLifeComponentSchema = createInsertSchema(lifeComponentsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertLifeComponent = z.infer<typeof insertLifeComponentSchema>;
export type LifeComponent = typeof lifeComponentsTable.$inferSelect;
